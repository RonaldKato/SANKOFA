# SANKOFA Health: Android app

An offline Android app that **demonstrates** and **validates** the paper's findings on the phone itself.

- **Ask**: pick a language, type a health question, and get either a vetted answer or an escalation to a person.
  The app uses the same per-language certified threshold as the paper. A "reading level" switch shows the
  literacy-register finding (Ugandan English), and a certified short list (conformal set) is shown for health-worker use.
  When the system escalates, the closest answer is hidden behind an explicit "demo only" button.
- **Validate**: re-runs the evaluation on the bundled validation split. It covers accuracy, chrF++, Recall@5 and nDCG@10
  against BM25, the parity check against the Python reference, the pooled vs per-language guarantee experiment, and
  the Akan keyboard test. You can share the report as text.
- **Findings**: plain-language summary of the results.

No internet permission, no account, no data leaves the phone. minSdk 24 (Android 7.0).

## Build

**Option A: Android Studio.** Open this folder and run the `app` configuration on a device or emulator.

**Option B: from the command line** (Android SDK installed, `ANDROID_HOME` set):
```bash
./gradlew :core:runParity      # Java engine vs Python reference (prints the table below)
./gradlew :app:assembleDebug   # APK at app/build/outputs/apk/debug/app-debug.apk
```

**Option C: no local setup.** Push this folder to a GitHub repository. The included workflow
`.github/workflows/build-apk.yml` runs the parity check and uploads the APK as a build artifact.

## Structure

- `core/`: pure-Java SANKOFA engine (no Android dependencies). It mirrors the Python code operation by operation,
  including numpy's float32 rounding, so the phone reproduces the paper's numbers.
  `ParityCheck` (in `core/src/test`) is a command-line validator.
- `app/`: the Android UI (Java, framework widgets only, no third-party libraries).
- `app/src/main/assets/sankofa/`: one model file per language subset, plus `manifest.json`. Regenerate with
  `python export_android_assets.py app/src/main/assets/sankofa` from the Python repo.

## Verified parity (JVM, same engine the app uses)

```
subset      acc   chrF    R@5   nDCG | bmAcc bmChrF | parity%  (python acc / chrF)
Aka_Gha    0.00  31.01    0.2    0.1 |  0.00  29.52 |  100.00   0.00 / 31.01
Amh_Eth    0.43  17.39    0.6    0.6 |  0.43  16.36 |  100.00   0.43 / 17.39
Eng_Eth   20.74  57.70   42.4   29.9 | 16.31  54.10 |  100.00  20.74 / 57.70
Eng_Gha    0.18  34.61    0.5    0.5 |  0.36  33.35 |  100.00   0.18 / 34.61
Eng_Ken   53.85  65.33   73.8   65.8 | 47.69  61.42 |  100.00  53.85 / 65.33
Eng_Uga   40.40  61.06   69.3   59.1 | 33.00  57.17 |  100.00  40.40 / 61.06
Lug_Uga   46.69  61.87   70.8   61.8 | 35.82  53.04 |  100.00  46.69 / 61.87
Swa_Ken   53.28  66.72   70.8   64.5 | 47.88  62.51 |  100.00  53.28 / 66.72

Guarantee experiment (lenient, alpha=0.2, delta=0.1, 300 splits)
English (Ethiopia), one pooled threshold: 25.7% wrong among answered, bound broken in 91.3% of splits
Per-language thresholds: bound broken in at most 1.0% of splits for every language
Akan keyboard test (chrF++): SANKOFA 31.01 -> 31.01, BM25 29.52 -> 25.35
```

The guarantee numbers differ slightly from the paper (25.6%, 92%) because Java and numpy draw different random splits.

## Important before any real-world use

- The answers come from a public research dataset. They are **not** reviewed for any country, and some local-language
  answers contain translation errors. This app is a research prototype, not a medical device.
- Replace `escalation_contact` in `app/src/main/res/values/strings.xml` with a verified, staffed local service.
- The app bundles text from the Kaggle dataset. Check the dataset's licence before distributing the APK publicly.
- The Android UI could not be built or run in the environment where it was written: the Android SDK was unreachable.
  It was compile-checked against stand-ins for the Android classes it uses. The engine itself was tested on the JVM.
  Expect to fix small issues on the first Android Studio build.
