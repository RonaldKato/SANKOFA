package org.sankofa.core;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * JVM check that the Java engine reproduces the Python results.
 * Usage: java -cp build org.sankofa.core.ParityCheck <assets_dir> [subset ...]
 */
public final class ParityCheck {
    public static void main(String[] args) throws Exception {
        Path dir = Paths.get(args[0]);
        List<String> subsets = new ArrayList<>();
        if (args.length > 1) for (int i = 1; i < args.length; i++) subsets.add(args[i]);
        else for (Object o : Json.list(Json.parse(Files.readString(dir.resolve("manifest.json"))))) subsets.add((String) Json.obj(o).get("subset"));
        List<Evaluator.SubsetReport> reps = new ArrayList<>();
        System.out.printf("%-8s %6s %6s %6s %6s %6s | %6s %6s | %8s %9s %7s%n", "subset", "acc", "chrF", "R@5", "nDCG", "ceil", "bmAcc", "bmChrF", "parity%", "maxConfΔ", "ms/q");
        for (String s : subsets) {
            Map<String, Object> a = Json.obj(Json.parse(new String(Files.readAllBytes(dir.resolve(s + ".json")), StandardCharsets.UTF_8)));
            Map<String, Object> ref = Json.obj(a.get("reference"));
            Evaluator.SubsetReport r = Evaluator.evaluate(a, null, true);
            reps.add(r);
            System.out.printf("%-8s %6.2f %6.2f %6.1f %6.1f %6.1f | %6.2f %6.2f | %8.2f %9.2e %7.2f   (python acc %.2f chrF %.2f)%n",
                    s, r.acc, r.chrf, r.r5, r.ndcg10, r.ceiling, r.bmAcc, r.bmChrf, r.parityTop, r.maxConfDiff, r.msPerQuery,
                    (Double) ref.get("acc"), (Double) ref.get("chrf"));
        }
        if (reps.size() > 1) {
            System.out.println("\nGuarantee experiment (lenient, alpha=0.2, delta=0.1, 300 splits):");
            System.out.printf("%-8s | %8s %7s %7s | %8s %7s %7s%n", "subset", "pool.cov", "risk", "viol", "lang.cov", "risk", "viol");
            for (Evaluator.GuaranteeRow g : Evaluator.guarantee(reps, true, 300, 0.2, 0.1, 0)) {
                System.out.printf("%-8s | %8.3f %7.3f %7.3f | %8.3f %7.3f %7.3f%n", g.subset, g.pooledCoverage, g.pooledRisk, g.pooledViolation, g.langCoverage, g.langRisk, g.langViolation);
            }
        }
    }
}
