package org.sankofa.core;

import java.text.Normalizer.Form;

/**
 * Script- and keyboard-aware normalization (port of sankofa/normalize.py).
 *  - Unicode NFC, unified apostrophes, lowercase
 *  - Amharic: Ethiopic punctuation -> ASCII, homophone folding, syllable = consonant + vowel letter
 *  - Akan: open vowels folded (ɛ -> e, ɔ -> o) for phone keyboards
 */
public final class Normalizer {
    private Normalizer() {}

    private static final String APOS = "’‘ʼ`´′";
    private static final String[][] ETH_PUNCT = {
            {"።", " . "}, {"፣", " , "}, {"፤", " ; "}, {"፥", " : "},
            {"፦", " : "}, {"፧", " ? "}, {"፡", " "}};
    private static final String[] VOWELS = {"e", "u", "i", "a", "E", "", "o", "W"};

    private static int homophone(int base) {
        switch (base) {
            case 0x1210: case 0x1280: return 0x1200; // ሐ ኀ -> ሀ
            case 0x1220: return 0x1230;              // ሠ -> ሰ
            case 0x12D0: return 0x12A0;              // ዐ -> አ
            case 0x1340: return 0x1338;              // ፀ -> ጸ
            default: return base;
        }
    }

    public static String normalize(String text, String lang) {
        if (text == null) return "";
        String t = java.text.Normalizer.normalize(text, Form.NFC);
        StringBuilder b = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); ) {
            int c = t.codePointAt(i);
            i += Character.charCount(c);
            if (APOS.indexOf(c) >= 0) b.append('\''); else b.appendCodePoint(c);
        }
        t = Py.lower(b.toString());
        if (lang.equals("Amh")) {
            for (String[] kv : ETH_PUNCT) t = t.replace(kv[0], kv[1]);
            StringBuilder e = new StringBuilder(t.length() * 2);
            for (int i = 0; i < t.length(); ) {
                int c = t.codePointAt(i);
                i += Character.charCount(c);
                if (c >= 0x1200 && c <= 0x137F && c < 0x1360) {
                    int off = (c - 0x1200) % 8;
                    int base = homophone(c - off);
                    e.appendCodePoint(base + 5).append(VOWELS[off]);
                } else e.appendCodePoint(c);
            }
            t = e.toString();
        }
        if (lang.equals("Aka")) t = t.replace("ɛ", "e").replace("ɔ", "o");
        StringBuilder q = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); ) {
            int c = t.codePointAt(i);
            i += Character.charCount(c);
            if ("\"“”«»()[]".indexOf(c) >= 0) q.append(' '); else q.appendCodePoint(c);
        }
        return Py.collapseSpaces(q.toString());
    }

    /** Python: " ".join(re.sub(r"[^\w\s]", " ", t.lower()).split()) */
    public static String canon(String t) {
        String l = Py.lower(t);
        StringBuilder b = new StringBuilder(l.length());
        for (int i = 0; i < l.length(); ) {
            int c = l.codePointAt(i);
            i += Character.charCount(c);
            if (Py.isWord(c) || Py.isSpace(c)) b.appendCodePoint(c); else b.append(' ');
        }
        return Py.collapseSpaces(b.toString());
    }
}
