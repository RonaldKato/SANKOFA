package org.sankofa.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Python-compatible string primitives (code points, str.split(), \w, \s, lower()). */
public final class Py {
    private Py() {}

    /** Python str.isspace() semantics (Unicode whitespace incl. NBSP, \x1c-\x1f, \x85). */
    public static boolean isSpace(int c) {
        if (c == ' ' || (c >= 0x09 && c <= 0x0d) || (c >= 0x1c && c <= 0x1f) || c == 0x85 || c == 0xa0) return true;
        if (c < 0x80) return false;
        return Character.isWhitespace(c) || Character.isSpaceChar(c);
    }

    /** Python regex \w (re.UNICODE): alphanumeric (str.isalnum) or underscore. */
    public static boolean isWord(int c) {
        if (c == '_') return true;
        if (Character.isLetter(c)) return true;
        int t = Character.getType(c);
        return t == Character.DECIMAL_DIGIT_NUMBER || t == Character.LETTER_NUMBER || t == Character.OTHER_NUMBER;
    }

    public static String lower(String s) { return s.toLowerCase(Locale.ROOT); }

    /** Python str.split() with no arguments. */
    public static List<String> split(String s) {
        List<String> out = new ArrayList<>();
        int n = s.length(), i = 0;
        while (i < n) {
            int c = s.codePointAt(i);
            if (isSpace(c)) { i += Character.charCount(c); continue; }
            int st = i;
            while (i < n) {
                int d = s.codePointAt(i);
                if (isSpace(d)) break;
                i += Character.charCount(d);
            }
            out.add(s.substring(st, i));
        }
        return out;
    }

    public static String join(String sep, List<String> parts, int from, int to) {
        StringBuilder b = new StringBuilder();
        for (int k = from; k < to; k++) { if (k > from) b.append(sep); b.append(parts.get(k)); }
        return b.toString();
    }

    /** Python str.strip() (whitespace). */
    public static String strip(String s) {
        int[] cp = s.codePoints().toArray();
        int a = 0, b = cp.length;
        while (a < b && isSpace(cp[a])) a++;
        while (b > a && isSpace(cp[b - 1])) b--;
        return new String(cp, a, b - a);
    }

    /** Python str.strip(chars) / rstrip(chars). */
    public static String strip(String s, String chars, boolean left, boolean right) {
        int[] cp = s.codePoints().toArray();
        int a = 0, b = cp.length;
        if (left) while (a < b && chars.indexOf(cp[a]) >= 0) a++;
        if (right) while (b > a && chars.indexOf(cp[b - 1]) >= 0) b--;
        return new String(cp, a, b - a);
    }

    /** Collapse whitespace runs to one space and strip (re.sub(r"\s+"," ",t).strip()). */
    public static String collapseSpaces(String s) {
        return String.join(" ", split(s));
    }

    /** Maximal runs of \w characters == re.findall(r"(?u)\b\w+\b", s). */
    public static List<String> wordTokens(String s) {
        List<String> out = new ArrayList<>();
        int n = s.length(), i = 0;
        while (i < n) {
            int c = s.codePointAt(i);
            if (!isWord(c)) { i += Character.charCount(c); continue; }
            int st = i;
            while (i < n) {
                int d = s.codePointAt(i);
                if (!isWord(d)) break;
                i += Character.charCount(d);
            }
            out.add(s.substring(st, i));
        }
        return out;
    }

    /** Python string ordering (by code point). */
    public static int compare(String a, String b) {
        int i = 0, j = 0;
        while (i < a.length() && j < b.length()) {
            int x = a.codePointAt(i), y = b.codePointAt(j);
            if (x != y) return Integer.compare(x, y);
            i += Character.charCount(x); j += Character.charCount(y);
        }
        return Integer.compare(a.length() - i, b.length() - j);
    }

    /** answer key used for exact-match comparison: " ".join(a.split()) */
    public static String akey(String a) { return String.join(" ", split(a)); }
}
