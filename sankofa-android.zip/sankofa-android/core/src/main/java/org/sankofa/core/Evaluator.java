package org.sankofa.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Re-runs the paper's evaluation on the bundled validation split:
 *   retrieval (accuracy, chrF++), recommendation (Recall@k, nDCG@10), BM25 baseline,
 *   parity with the Python reference, and the pooled-vs-per-language guarantee experiment.
 */
public final class Evaluator {
    public interface Progress { void update(String subset, int done, int total); }

    public static final class SubsetReport {
        public String subset, name;
        public int n;
        public double acc, chrf, r1, r5, r10, ndcg10, ceiling;
        public double bmAcc, bmChrf, bmR5;
        public double parityTop, maxConfDiff;
        public double[] confLenient, confStrict;
        public boolean[] wrongLenient, wrongStrict;
        public double msPerQuery;
    }

    public static SubsetReport evaluate(Map<String, Object> asset, Progress p, boolean withBaseline) {
        Engine e = Engine.fromAsset(asset);
        Engine bm = withBaseline ? Engine.bm25Baseline(asset) : null;
        Map<String, Object> val = Json.obj(asset.get("validation"));
        String[] qs = Json.strings(val.get("questions")), gold = Json.strings(val.get("gold"));
        Map<String, Object> ref = Json.obj(asset.get("reference"));
        int[] refTop = Json.ints(ref.get("top"));
        double[] refConf = Json.doubles(ref.get("conf_strict"));
        Map<String, Integer> idx = new HashMap<>();
        for (int c = 0; c < e.answers.length; c++) idx.putIfAbsent(Py.akey(e.answers[c]), c);

        SubsetReport rep = new SubsetReport();
        rep.subset = e.subset; rep.name = e.name; rep.n = qs.length;
        rep.confLenient = new double[qs.length]; rep.confStrict = new double[qs.length];
        rep.wrongLenient = new boolean[qs.length]; rep.wrongStrict = new boolean[qs.length];
        int same = 0, hits = 0, bmHits = 0, inBank = 0;
        double chrfSum = 0, bmChrfSum = 0, r1 = 0, r5 = 0, r10 = 0, nd = 0, bmR5 = 0;
        long t0 = System.nanoTime();
        for (int i = 0; i < qs.length; i++) {
            Engine.Result r = e.score(qs[i]);
            String pred = e.answers[r.top];
            boolean exact = Py.akey(pred).equals(Py.akey(gold[i]));
            double cf = Stats.chrf(pred, gold[i]);
            if (exact) hits++;
            chrfSum += cf;
            if (r.top == refTop[i]) same++;
            rep.maxConfDiff = Math.max(rep.maxConfDiff, Math.abs(r.confStrict - refConf[i]));
            rep.confStrict[i] = r.confStrict; rep.confLenient[i] = r.confLenient;
            rep.wrongStrict[i] = !exact; rep.wrongLenient[i] = !(exact || cf >= 50);
            Integer g = idx.get(Py.akey(gold[i]));
            if (g != null) {
                inBank++;
                int rank = rank(r.fused, g);
                if (rank <= 1) r1++;
                if (rank <= 5) r5++;
                if (rank <= 10) { r10++; nd += 1.0 / (Math.log(rank + 1) / Math.log(2)); }
            }
            if (bm != null) {
                Engine.Result b = bm.score(qs[i]);
                String bp = bm.answers[b.top];
                if (Py.akey(bp).equals(Py.akey(gold[i]))) bmHits++;
                bmChrfSum += Stats.chrf(bp, gold[i]);
                if (g != null && rank(b.fused, g) <= 5) bmR5++;
            }
            if (p != null && (i % 20 == 0 || i == qs.length - 1)) p.update(e.subset, i + 1, qs.length);
        }
        int n = qs.length;
        rep.msPerQuery = (System.nanoTime() - t0) / 1e6 / n;
        rep.acc = 100.0 * hits / n; rep.chrf = chrfSum / n; rep.ceiling = 100.0 * inBank / n;
        rep.r1 = 100 * r1 / n; rep.r5 = 100 * r5 / n; rep.r10 = 100 * r10 / n; rep.ndcg10 = 100 * nd / n;
        rep.parityTop = 100.0 * same / n;
        if (bm != null) { rep.bmAcc = 100.0 * bmHits / n; rep.bmChrf = bmChrfSum / n; rep.bmR5 = 100 * bmR5 / n; }
        return rep;
    }

    /** 1-based rank of item g with pessimistic tie-breaking (as in the paper) */
    static int rank(double[] f, int g) {
        double gs = f[g];
        int gt = 0, eq = 0;
        for (double x : f) { if (x > gs) gt++; else if (x == gs) eq++; }
        return gt + eq;
    }

    // -------------------------------------------------------------- guarantee experiment (Figure 3 of the paper)
    public static final class GuaranteeRow {
        public String subset;
        public double pooledCoverage, pooledRisk, pooledViolation, langCoverage, langRisk, langViolation;
    }

    public static List<GuaranteeRow> guarantee(List<SubsetReport> reps, boolean lenient, int reps_, double alpha, double delta, long seed) {
        double[] grid = Stats.defaultGrid();
        Random rng = new Random(seed);
        int S = reps.size();
        double[][] acc = new double[S][6];
        for (int t = 0; t < reps_; t++) {
            int[][] cal = new int[S][], tst = new int[S][];
            List<Double> pc = new ArrayList<>(); List<Boolean> pw = new ArrayList<>();
            for (int s = 0; s < S; s++) {
                int n = reps.get(s).n;
                int[] perm = new int[n];
                for (int i = 0; i < n; i++) perm[i] = i;
                for (int i = n - 1; i > 0; i--) { int j = rng.nextInt(i + 1); int x = perm[i]; perm[i] = perm[j]; perm[j] = x; }
                cal[s] = java.util.Arrays.copyOfRange(perm, 0, n / 2);
                tst[s] = java.util.Arrays.copyOfRange(perm, n / 2, n);
                double[] conf = lenient ? reps.get(s).confLenient : reps.get(s).confStrict;
                boolean[] wr = lenient ? reps.get(s).wrongLenient : reps.get(s).wrongStrict;
                for (int i : cal[s]) { pc.add(conf[i]); pw.add(wr[i]); }
            }
            double lamG = Stats.ltt(toD(pc), toB(pw), alpha, delta, grid);
            for (int s = 0; s < S; s++) {
                double[] conf = lenient ? reps.get(s).confLenient : reps.get(s).confStrict;
                boolean[] wr = lenient ? reps.get(s).wrongLenient : reps.get(s).wrongStrict;
                double[] cc = new double[cal[s].length]; boolean[] cw = new boolean[cal[s].length];
                for (int k = 0; k < cc.length; k++) { cc[k] = conf[cal[s][k]]; cw[k] = wr[cal[s][k]]; }
                double lamM = Stats.ltt(cc, cw, alpha, delta, grid);
                double[] lams = {lamG, lamM};
                for (int pol = 0; pol < 2; pol++) {
                    int ans = 0, bad = 0;
                    for (int i : tst[s]) if (conf[i] >= lams[pol]) { ans++; if (wr[i]) bad++; }
                    double cov = (double) ans / tst[s].length, risk = ans == 0 ? 0 : (double) bad / ans;
                    acc[s][pol * 3] += cov; acc[s][pol * 3 + 1] += risk; acc[s][pol * 3 + 2] += risk > alpha ? 1 : 0;
                }
            }
        }
        List<GuaranteeRow> out = new ArrayList<>();
        for (int s = 0; s < S; s++) {
            GuaranteeRow g = new GuaranteeRow();
            g.subset = reps.get(s).subset;
            g.pooledCoverage = acc[s][0] / reps_; g.pooledRisk = acc[s][1] / reps_; g.pooledViolation = acc[s][2] / reps_;
            g.langCoverage = acc[s][3] / reps_; g.langRisk = acc[s][4] / reps_; g.langViolation = acc[s][5] / reps_;
            out.add(g);
        }
        return out;
    }


    // -------------------------------------------------------------- keyboard robustness (Table 4 of the paper)
    /** chrF++ of SANKOFA and BM25 on clean vs perturbed validation questions: {sk_clean, sk_pert, bm_clean, bm_pert} */
    public static double[] robustness(Map<String, Object> asset, java.util.function.UnaryOperator<String> perturb, Progress p) {
        Engine e = Engine.fromAsset(asset), bm = Engine.bm25Baseline(asset);
        Map<String, Object> val = Json.obj(asset.get("validation"));
        String[] qs = Json.strings(val.get("questions")), gold = Json.strings(val.get("gold"));
        double[] out = new double[4];
        for (int i = 0; i < qs.length; i++) {
            String pq = perturb.apply(qs[i]);
            out[0] += Stats.chrf(e.answers[e.score(qs[i]).top], gold[i]);
            out[1] += Stats.chrf(e.answers[e.score(pq).top], gold[i]);
            out[2] += Stats.chrf(bm.answers[bm.score(qs[i]).top], gold[i]);
            out[3] += Stats.chrf(bm.answers[bm.score(pq).top], gold[i]);
            if (p != null && (i % 20 == 0 || i == qs.length - 1)) p.update(e.subset, i + 1, qs.length);
        }
        for (int k = 0; k < 4; k++) out[k] /= qs.length;
        return out;
    }

    /** Akan typed on a keyboard without the open vowels */
    public static String akanKeyboard(String q) {
        return q.replace("\u025b", "e").replace("\u0254", "o").replace("\u0190", "E").replace("\u0186", "O");
    }

    static double[] toD(List<Double> l) { double[] a = new double[l.size()]; for (int i = 0; i < a.length; i++) a[i] = l.get(i); return a; }
    static boolean[] toB(List<Boolean> l) { boolean[] a = new boolean[l.size()]; for (int i = 0; i < a.length; i++) a[i] = l.get(i); return a; }

    public static Map<String, Object> summary(SubsetReport r) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("subset", r.subset); m.put("acc", r.acc); m.put("chrf", r.chrf); m.put("R@5", r.r5); m.put("nDCG@10", r.ndcg10);
        m.put("bm25_acc", r.bmAcc); m.put("bm25_chrf", r.bmChrf); m.put("parity_top_%", r.parityTop); m.put("max_conf_diff", r.maxConfDiff);
        return m;
    }
}
