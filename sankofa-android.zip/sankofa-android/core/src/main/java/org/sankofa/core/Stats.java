package org.sankofa.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** chrF++ (sacreBLEU 2.x defaults), Learn-then-Test thresholds and split-conformal quantiles. */
public final class Stats {
    private Stats() {}

    // ------------------------------------------------------------------ chrF++ : char order 6, word order 2, beta 2
    private static final String PUNCTS = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";

    private static List<Map<String, Integer>> ngrams(String line) {
        List<Map<String, Integer>> out = new ArrayList<>();
        int[] cp = String.join("", Py.split(line)).codePoints().toArray();
        for (int n = 1; n <= 6; n++) {
            Map<String, Integer> m = new HashMap<>();
            for (int i = 0; i + n <= cp.length; i++) m.merge(new String(cp, i, n), 1, Integer::sum);
            out.add(m);
        }
        List<String> words = new ArrayList<>();
        for (String w : Py.split(line)) {
            int[] c = w.codePoints().toArray();
            if (c.length == 1) words.add(w);
            else if (PUNCTS.indexOf(c[c.length - 1]) >= 0) { words.add(new String(c, 0, c.length - 1)); words.add(new String(c, c.length - 1, 1)); }
            else if (PUNCTS.indexOf(c[0]) >= 0) { words.add(new String(c, 0, 1)); words.add(new String(c, 1, c.length - 1)); }
            else words.add(w);
        }
        for (int n = 1; n <= 2; n++) {
            Map<String, Integer> m = new HashMap<>();
            for (int i = 0; i + n <= words.size(); i++) m.merge(Py.join(" ", words, i, i + n), 1, Integer::sum);
            out.add(m);
        }
        return out;
    }

    public static double chrf(String hyp, String ref) {
        List<Map<String, Integer>> h = ngrams(hyp), r = ngrams(ref);
        double eps = 1e-16, factor = 4.0, avgP = 0, avgR = 0;
        int eff = 0;
        for (int o = 0; o < 8; o++) {
            Map<String, Integer> hm = h.get(o), rm = r.get(o);
            int hypC = 0, match = 0, refC = 0;
            for (Map.Entry<String, Integer> e : hm.entrySet()) {
                hypC += e.getValue();
                Integer rc = rm.get(e.getKey());
                if (rc != null) match += Math.min(e.getValue(), rc);
            }
            for (int v : rm.values()) refC += v;
            int nHyp = rm.isEmpty() ? 0 : hypC;
            double p = nHyp > 0 ? (double) match / nHyp : eps;
            double rr = refC > 0 ? (double) match / refC : eps;
            if (nHyp > 0 && refC > 0) { avgP += p; avgR += rr; eff++; }
        }
        if (eff == 0) return 0.0;
        avgP /= eff; avgR /= eff;
        if (avgP + avgR == 0) return 0.0;
        return 100 * (1 + factor) * avgP * avgR / (factor * avgP + avgR);
    }

    // ------------------------------------------------------------------ binomial CDF and Learn-then-Test
    static double logChoose(int n, int k) { return lgamma(n + 1) - lgamma(k + 1) - lgamma(n - k + 1); }

    static double lgamma(double x) { // Lanczos approximation, accurate to ~1e-13 for x > 0
        double[] g = {676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059,
                12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7};
        if (x < 0.5) return Math.log(Math.PI / Math.abs(Math.sin(Math.PI * x))) - lgamma(1 - x);
        x -= 1;
        double a = 0.99999999999980993, t = x + 7.5;
        for (int i = 0; i < 8; i++) a += g[i] / (x + i + 1);
        return 0.5 * Math.log(2 * Math.PI) + (x + 0.5) * Math.log(t) - t + Math.log(a);
    }

    public static double binomCdf(int k, int n, double p) {
        if (k >= n) return 1.0;
        double s = 0;
        for (int i = 0; i <= k; i++) s += Math.exp(logChoose(n, i) + i * Math.log(p) + (n - i) * Math.log1p(-p));
        return Math.min(1.0, s);
    }

    /** the 49-point grid 0.02..0.98 used in the paper */
    public static double[] defaultGrid() {
        double[] g = new double[49];
        for (int i = 0; i < 49; i++) g[i] = Math.round((0.02 * (i + 1)) * 100.0) / 100.0;
        return g;
    }

    /** smallest certified threshold, or +inf if none (escalate everything). Bonferroni over the grid. */
    public static double ltt(double[] conf, boolean[] wrong, double alpha, double delta, double[] grid) {
        double best = Double.POSITIVE_INFINITY;
        for (double lam : grid) {
            int n = 0, k = 0;
            for (int i = 0; i < conf.length; i++) if (conf[i] >= lam) { n++; if (wrong[i]) k++; }
            if (n == 0) continue;
            if (binomCdf(k, n, alpha) <= delta / grid.length) best = Math.min(best, lam);
        }
        return best;
    }

    /** split-conformal quantile of nonconformity scores (inf entries allowed); null when not achievable */
    public static Double conformalQuantile(double[] scores, double alpha) {
        double[] s = scores.clone();
        java.util.Arrays.sort(s);
        int n = s.length, k = (int) Math.ceil((n + 1) * (1 - alpha));
        if (k > n || Double.isInfinite(s[k - 1])) return null;
        return s[k - 1];
    }
}
