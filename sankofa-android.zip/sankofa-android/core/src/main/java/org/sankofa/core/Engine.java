package org.sankofa.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * SANKOFA engine for one language subset: dual-view retrieval over vetted answer clusters,
 * self-tuned fusion, confidence model and per-language decision rule.
 * Mirrors sankofa/retrieve.py + abstain.py, including numpy's float32 rounding where it occurs.
 */
public final class Engine {
    public static final String[] VIEWS = {"qq_char", "qq_word", "qq_bm25", "qa_char", "qa_word", "register"};

    public final String subset, lang, name;
    public final String[] answers;           // vetted answer per cluster
    public final int[] q2c;                  // training question -> cluster
    public final int nClusters;
    final boolean norm, scaffold;
    final boolean[] useView = new boolean[6];
    final double[] w = new double[6];
    double wSum;
    Scaffolds sc;
    Vectorizers.Tfidf cv, wv;
    Vectorizers.Index qqChar, qaChar, qqWord, qaWord;
    Vectorizers.Bm25 bm;
    int[] qreg;
    Map<String, Integer> regVocab;
    // confidence models: {coef..., intercept} or const
    double[] coefStrict, coefLenient; double interStrict, interLenient; Double constStrict, constLenient;
    public Double lambdaStrict, lambdaLenient, conformalQhat;

    /** Full SANKOFA configuration from an exported asset. */
    public static Engine fromAsset(Map<String, Object> a) { return new Engine(a, true); }

    /** Raw BM25 baseline over the same bank (no normalization, no scaffolds). */
    public static Engine bm25Baseline(Map<String, Object> a) { return new Engine(a, false); }

    private Engine(Map<String, Object> a, boolean full) {
        subset = (String) a.get("subset"); lang = (String) a.get("lang"); name = (String) a.get("name");
        Map<String, Object> bank = Json.obj(a.get("bank"));
        String[] qs = Json.strings(bank.get("questions"));
        q2c = Json.ints(bank.get("q2c"));
        answers = Json.strings(bank.get("answers"));
        nClusters = answers.length;
        norm = full; scaffold = full;
        if (full) {
            Map<String, Object> wt = Json.obj(a.get("weights"));
            for (int v = 0; v < 6; v++) {
                useView[v] = true;
                Object x = wt.get(VIEWS[v]);
                w[v] = x == null ? 0.0 : (Double) x;
                wSum += w[v];
            }
            Map<String, Object> s = Json.obj(a.get("scaffolds"));
            sc = new Scaffolds(Json.strings(s.get("suffix")), Json.strings(s.get("prefix")), Json.strings(s.get("openers")));
            Map<String, Object> conf = Json.obj(a.get("confidence"));
            Map<String, Object> st = Json.obj(conf.get("strict")), le = Json.obj(conf.get("lenient"));
            if (st.containsKey("const")) constStrict = (Double) st.get("const");
            else { coefStrict = Json.doubles(st.get("coef")); interStrict = (Double) st.get("intercept"); }
            if (le.containsKey("const")) constLenient = (Double) le.get("const");
            else { coefLenient = Json.doubles(le.get("coef")); interLenient = (Double) le.get("intercept"); }
            Map<String, Object> th = Json.obj(a.get("thresholds"));
            lambdaStrict = (Double) th.get("lambda_strict");
            lambdaLenient = (Double) th.get("lambda_lenient");
            conformalQhat = (Double) th.get("conformal_qhat");
        } else {
            useView[2] = true; w[2] = 1.0; wSum = 1.0;
        }
        build(qs);
    }

    String prepQuestion(String q) {
        String t = q == null ? "" : q;
        if (scaffold) t = sc.split(t)[0];
        return norm ? Normalizer.normalize(t, lang) : Py.lower(t);
    }

    String prepAnswer(String a) { return norm ? Normalizer.normalize(a, lang) : Py.lower(a); }

    private void build(String[] qs) {
        List<String> Q = new ArrayList<>(), A = new ArrayList<>();
        for (String q : qs) Q.add(prepQuestion(q));
        for (String a : answers) A.add(prepAnswer(a));
        List<String> fitDocs = new ArrayList<>(Q); fitDocs.addAll(A);
        if (useView[0] || useView[3]) {
            cv = new Vectorizers.Tfidf(true).fit(fitDocs);
            qqChar = index(cv, Q); qaChar = index(cv, A);
        }
        if (useView[1] || useView[4]) {
            wv = new Vectorizers.Tfidf(false).fit(fitDocs);
            qqWord = index(wv, Q); qaWord = index(wv, A);
        }
        if (useView[2]) bm = new Vectorizers.Bm25().fit(Q);
        if (useView[5]) {
            String[] regs = new String[qs.length];
            for (int i = 0; i < qs.length; i++) regs[i] = sc.split(qs[i])[1];
            String[] uniq = Arrays.stream(regs).distinct().sorted(Py::compare).toArray(String[]::new);
            regVocab = new HashMap<>();
            for (int k = 0; k < uniq.length; k++) regVocab.put(uniq[k], k);
            qreg = new int[qs.length];
            for (int i = 0; i < qs.length; i++) qreg[i] = regVocab.get(regs[i]);
        }
    }

    private static Vectorizers.Index index(Vectorizers.Tfidf v, List<String> docs) {
        List<Vectorizers.Vec> rows = new ArrayList<>();
        for (String d : docs) rows.add(v.transform(d));
        return new Vectorizers.Index(rows, v.idf.length);
    }

    /** max-pool question-level scores into clusters, stored as float32 like numpy */
    private float[] pool(double[] s) {
        float[] out = new float[nClusters];
        Arrays.fill(out, Float.NEGATIVE_INFINITY);
        double[] best = new double[nClusters];
        Arrays.fill(best, Double.NEGATIVE_INFINITY);
        for (int i = 0; i < s.length; i++) if (s[i] > best[q2c[i]]) best[q2c[i]] = s[i];
        for (int c = 0; c < nClusters; c++) out[c] = (float) best[c];
        return out;
    }

    private static void maxNorm(float[] v) {
        float mx = Float.NEGATIVE_INFINITY;
        for (float x : v) if (x > mx) mx = x;
        float d = mx > 0 ? mx : 1f;
        for (int i = 0; i < v.length; i++) v[i] = v[i] / d;
    }

    private static void maxNorm(double[] v) {
        double mx = Double.NEGATIVE_INFINITY;
        for (double x : v) if (x > mx) mx = x;
        double d = mx > 0 ? mx : 1.0;
        for (int i = 0; i < v.length; i++) v[i] = v[i] / d;
    }

    /** Result of scoring one question. */
    public static final class Result {
        public double[] fused;
        public double[][] view = new double[6][];
        public int top;
        public double topScore, margin, agree;
        public double[] sims = new double[6];
        public double confStrict, confLenient;
        public String register;
        public String normalized;

        /** clusters sorted by fused score (descending, ties by index) */
        public int[] ranking(int k) {
            Integer[] ids = new Integer[fused.length];
            for (int i = 0; i < ids.length; i++) ids[i] = i;
            Arrays.sort(ids, (a, b) -> fused[a] != fused[b] ? Double.compare(fused[b], fused[a]) : Integer.compare(a, b));
            int n = Math.min(k, ids.length);
            int[] out = new int[n];
            for (int i = 0; i < n; i++) out[i] = ids[i];
            return out;
        }
    }

    public Result score(String query) {
        Result r = new Result();
        String pq = prepQuestion(query);
        r.normalized = pq;
        float[] f32Pooled[] = new float[6][];
        double[][] f64 = new double[6][];
        if (useView[0] || useView[3]) {
            Vectorizers.Vec q = cv.transform(pq);
            if (useView[0]) { f32Pooled[0] = pool(qqChar.dot(q)); maxNorm(f32Pooled[0]); }
            if (useView[3]) { f64[3] = qaChar.dot(q); maxNorm(f64[3]); }
        }
        if (useView[1] || useView[4]) {
            Vectorizers.Vec q = wv.transform(pq);
            if (useView[1]) { f32Pooled[1] = pool(qqWord.dot(q)); maxNorm(f32Pooled[1]); }
            if (useView[4]) { f64[4] = qaWord.dot(q); maxNorm(f64[4]); }
        }
        if (useView[2]) { f32Pooled[2] = pool(bm.scores(pq)); maxNorm(f32Pooled[2]); }
        if (useView[5]) {
            String reg = sc.split(query)[1];
            r.register = reg;
            Integer qr = regVocab.get(reg);
            int qri = qr == null ? -1 : qr;
            double[] s = new double[qreg.length];
            for (int i = 0; i < s.length; i++) s[i] = qreg[i] == qri ? 1.0 : 0.0;
            f32Pooled[5] = pool(s);
        }
        // fused = sum in dict order; float32 partial sum until the first float64 view (numpy promotion)
        double[] fused = new double[nClusters];
        for (int c = 0; c < nClusters; c++) {
            float acc32 = 0f; double acc = 0; boolean promoted = false;
            for (int v = 0; v < 6; v++) {
                if (!useView[v]) continue;
                if (f32Pooled[v] != null) {
                    float term = ((float) w[v]) * f32Pooled[v][c];
                    if (!promoted) acc32 = acc32 + term; else acc = acc + term;
                } else {
                    if (!promoted) { acc = acc32; promoted = true; }
                    acc = acc + w[v] * f64[v][c];
                }
            }
            fused[c] = promoted ? acc : acc32;
        }
        r.fused = fused;
        for (int v = 0; v < 6; v++) {
            if (!useView[v]) continue;
            if (f32Pooled[v] != null) {
                double[] d = new double[nClusters];
                for (int c = 0; c < nClusters; c++) d[c] = f32Pooled[v][c];
                r.view[v] = d;
            } else r.view[v] = f64[v];
        }
        int top = argmax(fused);
        r.top = top;
        double best = Double.NEGATIVE_INFINITY, second = Double.NEGATIVE_INFINITY;
        for (double x : fused) { if (x > best) { second = best; best = x; } else if (x > second) second = x; }
        r.topScore = best;
        r.margin = nClusters > 1 ? best - second : best;
        int nv = 0, ag = 0;
        for (int v = 0; v < 6; v++) {
            if (!useView[v]) continue;
            nv++;
            if (argmax(r.view[v]) == top) ag++;
            r.sims[v] = r.view[v][top];
        }
        r.agree = nv == 0 ? 0 : (double) ag / nv;
        if (norm) {
            double[] x = features(r);
            r.confStrict = constStrict != null ? constStrict : sigmoid(dot(coefStrict, x) + interStrict);
            r.confLenient = constLenient != null ? constLenient : sigmoid(dot(coefLenient, x) + interLenient);
        }
        return r;
    }

    /** feature order: top_n, margin_n, agree, sim_qq_char, sim_qq_word, sim_qq_bm25, sim_qa_char, sim_qa_word, sim_register */
    double[] features(Result r) {
        double tot = wSum == 0 ? 1.0 : wSum;
        return new double[]{r.topScore / tot, r.margin / tot, r.agree,
                r.sims[0], r.sims[1], r.sims[2], r.sims[3], r.sims[4], r.sims[5]};
    }

    static int argmax(double[] a) {
        int b = 0;
        for (int i = 1; i < a.length; i++) if (a[i] > a[b]) b = i;
        return b;
    }

    static double dot(double[] a, double[] b) { double s = 0; for (int i = 0; i < a.length; i++) s += a[i] * b[i]; return s; }

    static double sigmoid(double z) { return 1.0 / (1.0 + Math.exp(-z)); }

    /** conformal recommendation list (indices of clusters), or null if the language has no certified q-hat */
    public int[] conformalList(Result r) {
        if (conformalQhat == null) return null;
        double mx = Math.max(r.topScore, 1e-9);
        List<Integer> ids = new ArrayList<>();
        for (int c = 0; c < nClusters; c++) if (1 - r.fused[c] / mx <= conformalQhat) ids.add(c);
        ids.sort((a, b) -> Double.compare(r.fused[b], r.fused[a]));
        return ids.stream().mapToInt(Integer::intValue).toArray();
    }
}
