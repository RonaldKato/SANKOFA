package org.sankofa.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Register-aware scaffold factorisation: question -> (content core, register). Port of split_scaffold. */
public final class Scaffolds {
    private final List<String> suffix, prefix;
    private final Set<String> openers;

    public Scaffolds(String[] suffix, String[] prefix, String[] openers) {
        Comparator<String> byLenDesc = (a, b) -> Integer.compare(cpLen(b), cpLen(a)); // stable, like sorted(key=-len)
        this.suffix = new ArrayList<>(Arrays.asList(suffix));
        this.suffix.sort(byLenDesc);
        this.prefix = new ArrayList<>(Arrays.asList(prefix));
        this.prefix.sort(byLenDesc);
        this.openers = new HashSet<>(Arrays.asList(openers));
    }

    static int cpLen(String s) { return s.codePointCount(0, s.length()); }

    /** returns {core, register}; register is "" when no scaffold wraps the question */
    public String[] split(String q0) {
        String q = q0 == null ? "" : Py.strip(q0);
        String cq = Normalizer.canon(q);
        int[] cqc = cq.codePoints().toArray();
        for (String aff : suffix) {
            String ca = Normalizer.canon(aff);
            int[] cac = ca.codePoints().toArray();
            if (cac.length == 0 || cqc.length <= cac.length + 3) continue;
            int[] tail = Arrays.copyOfRange(cqc, cqc.length - cac.length, cqc.length);
            if (Arrays.equals(tail, cac) || ratio(tail, cac) >= 0.85) {
                int nw = Py.split(ca).size();
                List<String> words = Py.split(q);
                String core = words.size() > nw ? Py.join(" ", words, 0, words.size() - nw) : q;
                return new String[]{Py.strip(core, " ,.;:", false, true), ca};
            }
        }
        for (String aff : prefix) {
            if (q.startsWith(aff + " ")) {
                String rest = Py.strip(q.substring(aff.length()));
                List<String> rw = Py.split(rest);
                if (!rw.isEmpty() && openers.contains(rw.get(0))) return new String[]{rest, Normalizer.canon(aff)};
            }
        }
        return new String[]{q, ""};
    }

    // ---------------- difflib.SequenceMatcher(None, a, b).ratio() (no junk; autojunk inactive for short b) ----
    static double ratio(int[] a, int[] b) {
        Map<Integer, List<Integer>> b2j = new HashMap<>();
        for (int j = 0; j < b.length; j++) b2j.computeIfAbsent(b[j], k -> new ArrayList<>()).add(j);
        if (b.length >= 200) { // CPython autojunk: drop "popular" elements
            int ntest = b.length / 100 + 1;
            b2j.entrySet().removeIf(e -> e.getValue().size() > ntest);
        }
        int matches = 0;
        List<int[]> queue = new ArrayList<>();
        queue.add(new int[]{0, a.length, 0, b.length});
        while (!queue.isEmpty()) {
            int[] r = queue.remove(queue.size() - 1);
            int alo = r[0], ahi = r[1], blo = r[2], bhi = r[3];
            int[] m = longest(a, b, b2j, alo, ahi, blo, bhi);
            int i = m[0], j = m[1], k = m[2];
            if (k > 0) {
                matches += k;
                if (alo < i && blo < j) queue.add(new int[]{alo, i, blo, j});
                if (i + k < ahi && j + k < bhi) queue.add(new int[]{i + k, ahi, j + k, bhi});
            }
        }
        int la = a.length + b.length;
        return la == 0 ? 1.0 : 2.0 * matches / la;
    }

    private static int[] longest(int[] a, int[] b, Map<Integer, List<Integer>> b2j, int alo, int ahi, int blo, int bhi) {
        int besti = alo, bestj = blo, bestsize = 0;
        Map<Integer, Integer> j2len = new HashMap<>();
        for (int i = alo; i < ahi; i++) {
            Map<Integer, Integer> newj2len = new HashMap<>();
            List<Integer> js = b2j.get(a[i]);
            if (js != null) for (int j : js) {
                if (j < blo) continue;
                if (j >= bhi) break;
                int k = j2len.getOrDefault(j - 1, 0) + 1;
                newj2len.put(j, k);
                if (k > bestsize) { besti = i - k + 1; bestj = j - k + 1; bestsize = k; }
            }
            j2len = newj2len;
        }
        while (besti > alo && bestj > blo && a[besti - 1] == b[bestj - 1]) { besti--; bestj--; bestsize++; }
        while (besti + bestsize < ahi && bestj + bestsize < bhi && a[besti + bestsize] == b[bestj + bestsize]) bestsize++;
        return new int[]{besti, bestj, bestsize};
    }
}
