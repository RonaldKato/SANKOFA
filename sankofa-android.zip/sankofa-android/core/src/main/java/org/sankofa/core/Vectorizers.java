package org.sankofa.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * scikit-learn compatible TF-IDF (char_wb 2-5 and word 1-2, sublinear_tf, smooth idf, l2)
 * and the BM25 variant used in sankofa/retrieve.py. Matrices are kept as inverted indexes so a
 * query touches only the postings of its own features.
 */
public final class Vectorizers {
    private Vectorizers() {}

    /** sparse vector: sorted feature ids + values */
    public static final class Vec {
        public final int[] idx; public final double[] val;
        Vec(int[] idx, double[] val) { this.idx = idx; this.val = val; }
    }

    // ------------------------------------------------------------------ analyzers
    static List<String> charWb(String doc) {
        List<String> out = new ArrayList<>();
        for (String w0 : Py.split(Py.lower(doc))) {
            int[] w = (" " + w0 + " ").codePoints().toArray();
            for (int n = 2; n <= 5; n++) {
                int offset = 0;
                out.add(new String(w, offset, Math.min(n, w.length - offset)));
                while (offset + n < w.length) {
                    offset++;
                    out.add(new String(w, offset, n));
                }
                if (offset == 0) break;
            }
        }
        return out;
    }

    static List<String> words12(String doc) {
        List<String> toks = Py.wordTokens(Py.lower(doc));
        List<String> out = new ArrayList<>(toks);
        int n0 = toks.size();
        for (int n = 2; n < Math.min(3, n0 + 1); n++)
            for (int i = 0; i + n <= n0; i++) out.add(Py.join(" ", toks, i, i + n));
        return out;
    }

    // ------------------------------------------------------------------ TF-IDF
    public static final class Tfidf {
        final boolean charMode;
        Map<String, Integer> vocab;
        double[] idf;

        public Tfidf(boolean charMode) { this.charMode = charMode; }

        List<String> analyze(String d) { return charMode ? charWb(d) : words12(d); }

        public Tfidf fit(List<String> docs) {
            Map<String, Integer> df = new HashMap<>();
            for (String d : docs) {
                for (String t : new java.util.HashSet<>(analyze(d))) df.merge(t, 1, Integer::sum);
            }
            String[] terms = df.keySet().toArray(new String[0]);
            Arrays.sort(terms, Py::compare);            // sklearn sorts vocabulary alphabetically
            vocab = new HashMap<>(terms.length * 2);
            idf = new double[terms.length];
            int n = docs.size();
            for (int k = 0; k < terms.length; k++) {
                vocab.put(terms[k], k);
                idf[k] = Math.log((1.0 + n) / (1.0 + df.get(terms[k]))) + 1.0;
            }
            return this;
        }

        public Vec transform(String d) {
            Map<Integer, Integer> tf = new HashMap<>();
            for (String t : analyze(d)) { Integer id = vocab.get(t); if (id != null) tf.merge(id, 1, Integer::sum); }
            int[] idx = new int[tf.size()];
            int p = 0;
            for (int k : tf.keySet()) idx[p++] = k;
            Arrays.sort(idx);
            double[] val = new double[idx.length];
            double ss = 0;
            for (int k = 0; k < idx.length; k++) {
                val[k] = (Math.log(tf.get(idx[k])) + 1.0) * idf[idx[k]];
                ss += val[k] * val[k];
            }
            double norm = Math.sqrt(ss);
            if (norm > 0) for (int k = 0; k < val.length; k++) val[k] /= norm;
            return new Vec(idx, val);
        }
    }

    /** column-oriented (inverted) index of a document-term matrix */
    public static final class Index {
        final int nDocs;
        final int[][] docs; final double[][] vals;

        public Index(List<Vec> rows, int nFeatures) {
            nDocs = rows.size();
            int[] cnt = new int[nFeatures];
            for (Vec v : rows) for (int f : v.idx) cnt[f]++;
            docs = new int[nFeatures][]; vals = new double[nFeatures][];
            for (int f = 0; f < nFeatures; f++) { docs[f] = new int[cnt[f]]; vals[f] = new double[cnt[f]]; }
            int[] pos = new int[nFeatures];
            for (int r = 0; r < rows.size(); r++) {
                Vec v = rows.get(r);
                for (int k = 0; k < v.idx.length; k++) {
                    int f = v.idx[k];
                    docs[f][pos[f]] = r; vals[f][pos[f]] = v.val[k]; pos[f]++;
                }
            }
        }

        /** dot product of q with every document */
        public double[] dot(Vec q) {
            double[] out = new double[nDocs];
            for (int k = 0; k < q.idx.length; k++) {
                int f = q.idx[k]; double w = q.val[k];
                int[] d = docs[f]; double[] v = vals[f];
                for (int j = 0; j < d.length; j++) out[d[j]] += w * v[j];
            }
            return out;
        }
    }

    // ------------------------------------------------------------------ BM25 (k1=1.5, b=0.75), float32 like numpy
    public static final class Bm25 {
        Map<String, Integer> vocab;
        int[][] docs; float[][] w;
        int nDocs;

        public Bm25 fit(List<String> qs) {
            nDocs = qs.size();
            List<Map<String, Integer>> tfs = new ArrayList<>();
            Map<String, Integer> df = new HashMap<>();
            for (String d : qs) {
                Map<String, Integer> tf = new HashMap<>();
                for (String t : Py.wordTokens(Py.lower(d))) tf.merge(t, 1, Integer::sum);
                tfs.add(tf);
                for (String t : tf.keySet()) df.merge(t, 1, Integer::sum);
            }
            String[] terms = df.keySet().toArray(new String[0]);
            Arrays.sort(terms, Py::compare);
            vocab = new HashMap<>();
            for (int k = 0; k < terms.length; k++) vocab.put(terms[k], k);
            float[] dl = new float[nDocs];
            double sum = 0;
            for (int r = 0; r < nDocs; r++) { int s = 0; for (int c : tfs.get(r).values()) s += c; dl[r] = s; sum += s; }
            float mean = (float) (sum / nDocs);
            float[] idf = new float[terms.length];
            for (int k = 0; k < terms.length; k++) {
                int d = df.get(terms[k]);
                idf[k] = (float) Math.log(1 + (nDocs - d + 0.5) / (d + 0.5));
            }
            int[] cnt = new int[terms.length];
            for (Map<String, Integer> tf : tfs) for (String t : tf.keySet()) cnt[vocab.get(t)]++;
            docs = new int[terms.length][]; w = new float[terms.length][];
            for (int k = 0; k < terms.length; k++) { docs[k] = new int[cnt[k]]; w[k] = new float[cnt[k]]; }
            int[] pos = new int[terms.length];
            final float k1 = 1.5f, b = 0.75f, oneMinusB = (float) (1 - 0.75);
            for (int r = 0; r < nDocs; r++) {
                for (Map.Entry<String, Integer> e : tfs.get(r).entrySet()) {
                    int f = vocab.get(e.getKey());
                    float tf = e.getValue();
                    float lenNorm = oneMinusB + (b * dl[r]) / mean;
                    float denom = tf + k1 * lenNorm;
                    float wt = tf * (k1 + 1f) / denom * idf[f];
                    docs[f][pos[f]] = r; w[f][pos[f]] = wt; pos[f]++;
                }
            }
            return this;
        }

        public double[] scores(String q) {
            double[] out = new double[nDocs];
            for (String t : new java.util.LinkedHashSet<>(Py.wordTokens(Py.lower(q)))) {
                Integer f = vocab.get(t);
                if (f == null) continue;
                int[] d = docs[f]; float[] v = w[f];
                for (int j = 0; j < d.length; j++) out[d[j]] += (double) v[j];
            }
            return out;
        }
    }
}
