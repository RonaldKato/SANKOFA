package org.sankofa.app;

import android.content.Context;

import org.sankofa.core.Engine;
import org.sankofa.core.Json;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Loads the bundled per-language models from assets/sankofa and keeps one engine in memory. */
public final class AssetStore {
    public static final class Entry {
        public final String subset, name;
        public final int nBank, nClusters, nVal;
        public final double refAcc, refChrf;
        Entry(Map<String, Object> m) {
            subset = (String) m.get("subset");
            name = (String) m.get("name");
            nBank = ((Double) m.get("n_bank")).intValue();
            nClusters = ((Double) m.get("n_clusters")).intValue();
            nVal = ((Double) m.get("n_val")).intValue();
            refAcc = (Double) m.get("ref_acc");
            refChrf = (Double) m.get("ref_chrf");
        }
        @Override public String toString() { return name; }
    }

    private final Context ctx;
    public final List<Entry> entries = new ArrayList<>();
    private String cachedSubset;
    private Engine cachedEngine;
    private Map<String, Object> cachedAsset;

    public AssetStore(Context ctx) throws IOException {
        this.ctx = ctx.getApplicationContext();
        for (Object o : Json.list(Json.parse(read("sankofa/manifest.json")))) entries.add(new Entry(Json.obj(o)));
    }

    private String read(String path) throws IOException {
        try (InputStream in = ctx.getAssets().open(path)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    /** raw asset (bank, weights, thresholds, validation split) for one subset */
    public synchronized Map<String, Object> asset(String subset) throws IOException {
        if (subset.equals(cachedSubset) && cachedAsset != null) return cachedAsset;
        cachedEngine = null;
        cachedAsset = Json.obj(Json.parse(read("sankofa/" + subset + ".json")));
        cachedSubset = subset;
        return cachedAsset;
    }

    /** the SANKOFA engine for one subset (built on first use, then cached) */
    public synchronized Engine engine(String subset) throws IOException {
        Map<String, Object> a = asset(subset);
        if (cachedEngine == null) cachedEngine = Engine.fromAsset(a);
        return cachedEngine;
    }

    /** free the cached language before a memory-heavy validation run */
    public synchronized void release() { cachedEngine = null; cachedAsset = null; cachedSubset = null; }
}
