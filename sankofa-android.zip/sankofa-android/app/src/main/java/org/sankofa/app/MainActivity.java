package org.sankofa.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.IOException;

/** Three screens: Ask (demonstrate), Validate (re-run the paper's evaluation on the phone), Findings. */
public class MainActivity extends Activity {
    private FrameLayout content;
    private View ask, validate, findings;
    private Button bAsk, bVal, bFind;
    AssetStore store;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.column(this);

        LinearLayout header = Ui.column(this);
        header.setBackgroundColor(Ui.PRIMARY);
        int p = Ui.dp(this, 16);
        header.setPadding(p, Ui.dp(this, 20), p, Ui.dp(this, 12));
        header.addView(Ui.text(this, "SANKOFA Health", 22, true, 0xFFFFFFFF));
        TextView sub = Ui.text(this, "Vetted answers or a person. Offline, in 5 African languages.", 13, false, 0xFFDDE6F0);
        header.addView(sub);
        root.addView(header);

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout nav = Ui.row(this);
        nav.setBackgroundColor(Ui.CARD);
        bAsk = Ui.button(this, "Ask", v -> show(0));
        bVal = Ui.button(this, "Validate", v -> show(1));
        bFind = Ui.button(this, "Findings", v -> show(2));
        for (Button b : new Button[]{bAsk, bVal, bFind})
            nav.addView(b, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(nav);
        setContentView(root);

        try {
            store = new AssetStore(this);
        } catch (IOException e) {
            content.addView(Ui.text(this, "Could not load bundled models: " + e.getMessage(), 15, false, Ui.WARN));
            return;
        }
        show(0);
    }

    private void show(int which) {
        if (store == null) return;
        content.removeAllViews();
        if (which == 0) { if (ask == null) ask = new AskScreen(this, store).build(); content.addView(ask); }
        if (which == 1) { if (validate == null) validate = new ValidateScreen(this, store).build(); content.addView(validate); }
        if (which == 2) { if (findings == null) findings = FindingsScreen.build(this); content.addView(findings); }
        bAsk.setEnabled(which != 0); bVal.setEnabled(which != 1); bFind.setEnabled(which != 2);
    }
}
