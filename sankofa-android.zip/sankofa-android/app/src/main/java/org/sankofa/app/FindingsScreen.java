package org.sankofa.app;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/** Plain-language summary of what the paper found and what this app lets you check. */
final class FindingsScreen {
    private FindingsScreen() {}

    private static final String[][] FINDINGS = {
            {"The instruction is the answer",
                    "In Ugandan English, endings like \"please answer in detail\" or \"in simple medical terms\" pick a different vetted answer 97.9% of the time. "
                            + "Treating them as noise drops accuracy from 40.4% to 21.0%. In the Ask screen, switch the reading level to see it."},
            {"Better than keyword search in every language",
                    "Across 8 subsets, macro chrF++ rises from 45.94 (BM25) to 49.46 and vetted-answer accuracy from 22.69% to 26.95%. "
                            + "Luganda gains 10.9 points. Validate → Run validation reproduces these numbers on the phone."},
            {"Phone keyboards don't break it",
                    "Typing Akan without ɛ/ɔ costs BM25 4.1 chrF++ points and costs SANKOFA nothing. Validate → Keyboard test."},
            {"A good recommender for health",
                    "Treating past questions as history and answer text as content raises Recall@5 from 56.6 to 65.4. "
                            + "Answers asked only once gain the most, and popular answers are not over-recommended."},
            {"Safety must hold for every language",
                    "One shared threshold gives Ethiopian English users 25.6% wrong answers, breaking the 20% promise in 92% of trials. "
                            + "Per-language thresholds keep every language under 20%. Validate → All 8 subsets shows this live."},
            {"Honest about gaps",
                    "For Akan, Ghanaian English and Amharic the vetted bank rarely holds the exact answer, so the system escalates every question. "
                            + "That is the safe behaviour, and it shows curators where the bank must grow."},
            {"Built for low-resource settings",
                    "No internet, no GPU, no account. Answers come back in a few milliseconds, and nothing you type leaves the phone."},
    };

    static View build(Activity act) {
        ScrollView sv = new ScrollView(act);
        LinearLayout col = Ui.column(act);
        int p = Ui.dp(act, 16);
        col.setPadding(p, p, p, p);
        sv.addView(col);
        col.addView(Ui.text(act, "What the research found", 17, true, Ui.INK));
        for (String[] f : FINDINGS) {
            LinearLayout c = Ui.card(act, Ui.CARD);
            c.addView(Ui.text(act, f[0], 15, true, Ui.PRIMARY));
            c.addView(Ui.text(act, f[1], 13, false, Ui.INK), Ui.gap(act, 4));
            col.addView(c, Ui.gap(act, 10));
        }
        LinearLayout lim = Ui.card(act, 0xFFFFF4E5);
        lim.addView(Ui.text(act, "Research prototype", 15, true, Ui.WARN));
        lim.addView(Ui.text(act, "Answers come from a public research dataset and have not been reviewed for any specific country. "
                + "Some local-language answers contain translation errors. Do not use this app for medical decisions; "
                + "talk to a health worker.", 13, false, Ui.INK), Ui.gap(act, 4));
        col.addView(lim, Ui.gap(act, 14));
        return sv;
    }
}
