package org.sankofa.app;

import android.app.Activity;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import org.sankofa.core.Engine;
import org.sankofa.core.Json;

import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Demonstration screen: type a question, get a vetted answer or an escalation.
 * When the language has no certified threshold or confidence is below it, the closest vetted
 * answer is hidden behind an explicit "demo only" button.
 */
final class AskScreen {
    private final Activity act;
    private final AssetStore store;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Random rnd = new Random();

    private Spinner lang;
    private TextView info, status;
    private EditText input;
    private RadioGroup register;
    private RadioButton regNone, regSimple, regDetail;
    private LinearLayout result;
    private String simpleSuffix, detailSuffix;

    AskScreen(Activity act, AssetStore store) { this.act = act; this.store = store; }

    View build() {
        ScrollView sv = new ScrollView(act);
        LinearLayout col = Ui.column(act);
        int p = Ui.dp(act, 16);
        col.setPadding(p, p, p, p);
        sv.addView(col);

        col.addView(Ui.text(act, "Language", 13, true, Ui.QUIET));
        lang = new Spinner(act);
        ArrayAdapter<AssetStore.Entry> ad = new ArrayAdapter<>(act, android.R.layout.simple_spinner_item, store.entries);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        lang.setAdapter(ad);
        int uga = 0;
        for (int i = 0; i < store.entries.size(); i++) if (store.entries.get(i).subset.equals("Lug_Uga")) uga = i;
        lang.setSelection(uga);
        col.addView(lang);

        info = Ui.text(act, "", 12, false, Ui.QUIET);
        col.addView(info, Ui.gap(act, 4));

        input = new EditText(act);
        input.setHint("Type a health question, in the language chosen above");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setMinLines(2);
        col.addView(input, Ui.gap(act, 10));

        col.addView(Ui.text(act, "Reading level (only where the data has literacy registers)", 12, false, Ui.QUIET), Ui.gap(act, 6));
        register = new RadioGroup(act);
        register.setOrientation(RadioGroup.HORIZONTAL);
        regNone = radio("As typed"); regSimple = radio("Simple terms"); regDetail = radio("In detail");
        register.addView(regNone); register.addView(regSimple); register.addView(regDetail);
        regNone.setChecked(true);
        col.addView(register);

        LinearLayout buttons = Ui.row(act);
        Button go = Ui.button(act, "Get vetted answer", v -> ask());
        Button ex = Ui.button(act, "Example question", v -> example());
        buttons.addView(go, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        buttons.addView(ex, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(buttons, Ui.gap(act, 8));

        status = Ui.text(act, "", 12, false, Ui.QUIET);
        col.addView(status, Ui.gap(act, 4));
        result = Ui.column(act);
        col.addView(result, Ui.gap(act, 8));

        lang.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { load(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        return sv;
    }

    private RadioButton radio(String s) {
        RadioButton r = new RadioButton(act);
        r.setText(s);
        r.setId(View.generateViewId());
        return r;
    }

    private String subset() { return ((AssetStore.Entry) lang.getSelectedItem()).subset; }

    /** build (or fetch) the engine for the selected language in the background */
    private void load() {
        final String s = subset();
        status.setText("Loading the vetted answer bank…");
        result.removeAllViews();
        exec.execute(() -> {
            try {
                Engine e = store.engine(s);
                Map<String, Object> a = store.asset(s);
                simpleSuffix = null; detailSuffix = null;
                for (String suf : Json.strings(Json.obj(a.get("scaffolds")).get("suffix"))) {
                    String l = suf.toLowerCase(Locale.ROOT);
                    if (simpleSuffix == null && l.contains("simple")) simpleSuffix = suf;
                    if (detailSuffix == null && l.contains("detail")) detailSuffix = suf;
                }
                String lam = e.lambdaStrict == null ? "no certified threshold: every question is escalated"
                        : String.format(Locale.ROOT, "answers only when confidence ≥ %.2f", e.lambdaStrict);
                String txt = String.format(Locale.ROOT, "%,d vetted answers · %s", e.nClusters, lam);
                act.runOnUiThread(() -> {
                    info.setText(txt);
                    boolean hasReg = simpleSuffix != null && detailSuffix != null;
                    regSimple.setEnabled(hasReg); regDetail.setEnabled(hasReg);
                    if (!hasReg) regNone.setChecked(true);
                    status.setText("Ready. Runs fully offline.");
                });
            } catch (Exception ex) {
                act.runOnUiThread(() -> status.setText("Could not load: " + ex.getMessage()));
            }
        });
    }

    private void example() {
        final String s = subset();
        exec.execute(() -> {
            try {
                String[] qs = Json.strings(Json.obj(store.asset(s).get("validation")).get("questions"));
                String q = qs[rnd.nextInt(qs.length)];
                act.runOnUiThread(() -> { input.setText(q); ask(); });
            } catch (Exception ignored) { }
        });
    }

    private void ask() {
        final String s = subset();
        String q = input.getText().toString().trim();
        if (q.isEmpty()) { status.setText("Type a question first."); return; }
        if (regSimple.isChecked() && simpleSuffix != null && !q.toLowerCase(Locale.ROOT).contains("simple")) q = q + ", " + simpleSuffix;
        if (regDetail.isChecked() && detailSuffix != null && !q.toLowerCase(Locale.ROOT).contains("detail")) q = q + ", " + detailSuffix;
        final String query = q;
        status.setText("Searching the vetted bank…");
        exec.execute(() -> {
            try {
                Engine e = store.engine(s);
                long t0 = System.nanoTime();
                Engine.Result r = e.score(query);
                int[] list = e.conformalList(r);
                double ms = (System.nanoTime() - t0) / 1e6;
                act.runOnUiThread(() -> show(e, r, list, ms));
            } catch (Exception ex) {
                act.runOnUiThread(() -> status.setText("Error: " + ex.getMessage()));
            }
        });
    }

    private void show(Engine e, Engine.Result r, int[] list, double ms) {
        result.removeAllViews();
        status.setText(String.format(Locale.ROOT, "Answered in %.1f ms on this phone.", ms));
        boolean certified = e.lambdaStrict != null;
        boolean answer = certified && r.confStrict >= e.lambdaStrict;

        LinearLayout card = Ui.card(act, answer ? 0xFFE8F5EC : 0xFFFFF4E5);
        String head = answer ? "Vetted answer" : "Escalate to a person";
        card.addView(Ui.text(act, head, 18, true, answer ? Ui.GOOD : Ui.WARN));
        String why = certified
                ? String.format(Locale.ROOT, "Confidence %.2f %s the certified threshold %.2f for %s.",
                    r.confStrict, answer ? "≥" : "<", e.lambdaStrict, e.name)
                : "No threshold could be certified for " + e.name + " (the vetted bank rarely contains the exact answer), so every question goes to a person.";
        card.addView(Ui.text(act, why, 12, false, Ui.QUIET), Ui.gap(act, 2));

        final String best = e.answers[r.top];
        if (answer) {
            card.addView(Ui.text(act, best, 15, false, Ui.INK), Ui.gap(act, 10));
        } else {
            card.addView(Ui.text(act, act.getString(R.string.escalation_contact), 15, false, Ui.INK), Ui.gap(act, 10));
            TextView demo = Ui.text(act, "", 14, false, Ui.QUIET);
            Button reveal = Ui.button(act, "Show closest vetted answer (demo only)", v -> demo.setText(best));
            card.addView(reveal, Ui.gap(act, 6));
            card.addView(demo);
        }
        StringBuilder meta = new StringBuilder("Read as: ").append(r.normalized);
        if (r.register != null && !r.register.isEmpty()) meta.append("\nReading level detected: ").append(r.register);
        card.addView(Ui.text(act, meta, 11, false, Ui.QUIET), Ui.gap(act, 10));
        result.addView(card);

        if (list != null && list.length > 0) {
            LinearLayout lc = Ui.card(act, Ui.CARD);
            lc.addView(Ui.text(act, String.format(Locale.ROOT,
                    "Short list for a health worker: %d vetted answer%s. For %s, lists like this contain the right answer 80%% of the time.",
                    list.length, list.length == 1 ? "" : "s", e.name), 13, true, Ui.INK));
            TextView items = Ui.text(act, "", 13, false, Ui.INK);
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < Math.min(list.length, 12); i++) {
                String a = e.answers[list[i]];
                b.append(i + 1).append(". ").append(a.length() > 220 ? a.substring(0, 220) + "…" : a).append("\n\n");
            }
            if (list.length > 12) b.append("… and ").append(list.length - 12).append(" more");
            Button showList = Ui.button(act, "Show the list", v -> items.setText(b.toString()));
            lc.addView(showList, Ui.gap(act, 6));
            lc.addView(items);
            result.addView(lc, Ui.gap(act, 10));
        }
    }
}
