package org.sankofa.app;

import android.app.Activity;
import android.content.Intent;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import org.sankofa.core.Evaluator;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Re-runs the paper's evaluation on the phone, on the bundled validation split:
 * accuracy / chrF++ / Recall@5 / nDCG@10 vs BM25, parity with the Python reference,
 * the pooled-vs-per-language guarantee experiment, and the Akan keyboard test.
 */
final class ValidateScreen {
    private final Activity act;
    private final AssetStore store;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private Spinner which;
    private CheckBox baseline;
    private EditText splits;
    private ProgressBar bar;
    private TextView status, out;
    private Button run, akan, share;
    private final StringBuilder report = new StringBuilder();

    ValidateScreen(Activity act, AssetStore store) { this.act = act; this.store = store; }

    View build() {
        ScrollView sv = new ScrollView(act);
        LinearLayout col = Ui.column(act);
        int p = Ui.dp(act, 16);
        col.setPadding(p, p, p, p);
        sv.addView(col);

        col.addView(Ui.text(act, "Reproduce the paper on this phone", 17, true, Ui.INK));
        col.addView(Ui.text(act, "Runs the same engine on the bundled validation questions, compares it with BM25 and with the "
                + "Python reference, then repeats the safety-guarantee experiment with random calibration splits.", 13, false, Ui.QUIET), Ui.gap(act, 4));

        List<String> opts = new ArrayList<>();
        opts.add("All 8 subsets (needed for the guarantee experiment)");
        for (AssetStore.Entry e : store.entries) opts.add(e.name + " (" + e.subset + ")");
        which = new Spinner(act);
        ArrayAdapter<String> ad = new ArrayAdapter<>(act, android.R.layout.simple_spinner_item, opts);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        which.setAdapter(ad);
        col.addView(which, Ui.gap(act, 10));

        baseline = new CheckBox(act);
        baseline.setText("Also run the BM25 baseline");
        baseline.setChecked(true);
        col.addView(baseline);

        LinearLayout sp = Ui.row(act);
        sp.addView(Ui.text(act, "Calibration splits: ", 13, false, Ui.INK));
        splits = new EditText(act);
        splits.setInputType(InputType.TYPE_CLASS_NUMBER);
        splits.setText("100");
        sp.addView(splits, new LinearLayout.LayoutParams(Ui.dp(act, 90), LinearLayout.LayoutParams.WRAP_CONTENT));
        col.addView(sp);

        run = Ui.button(act, "Run validation", v -> runValidation());
        col.addView(run, Ui.gap(act, 6));
        akan = Ui.button(act, "Keyboard test: Akan typed without ɛ / ɔ", v -> runAkan());
        col.addView(akan);

        bar = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        col.addView(bar, Ui.gap(act, 10));
        status = Ui.text(act, "", 12, false, Ui.QUIET);
        col.addView(status);

        out = Ui.mono(act, "");
        LinearLayout card = Ui.card(act, Ui.CARD);
        HorizontalScrollView hs = new HorizontalScrollView(act);   // report rows are wider than a phone screen
        hs.addView(out);
        card.addView(hs);
        col.addView(card, Ui.gap(act, 10));

        share = Ui.button(act, "Share report", v -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, "SANKOFA on-device validation");
            i.putExtra(Intent.EXTRA_TEXT, report.toString());
            act.startActivity(Intent.createChooser(i, "Share report"));
        });
        share.setEnabled(false);
        col.addView(share, Ui.gap(act, 8));
        return sv;
    }

    private void busy(boolean b) {
        run.setEnabled(!b); akan.setEnabled(!b); which.setEnabled(!b);
        if (!b) share.setEnabled(report.length() > 0);
    }

    private void print(String line) {
        act.runOnUiThread(() -> { report.append(line).append('\n'); out.setText(report.toString()); });
    }

    private void runValidation() {
        final int sel = which.getSelectedItemPosition();
        final boolean bm = baseline.isChecked();
        int r;
        try { r = Math.max(10, Integer.parseInt(splits.getText().toString())); } catch (NumberFormatException e) { r = 100; }
        final int reps = r;
        report.setLength(0);
        out.setText("");
        busy(true);
        exec.execute(() -> {
            List<AssetStore.Entry> todo = new ArrayList<>();
            if (sel == 0) todo.addAll(store.entries); else todo.add(store.entries.get(sel - 1));
            List<Evaluator.SubsetReport> reps_ = new ArrayList<>();
            print(String.format(Locale.ROOT, "%-8s %6s %6s %5s %5s %6s %6s %7s", "subset", "acc", "chrF", "R@5", "nDCG", "bmAcc", "bmChrF", "parity"));
            try {
                for (int k = 0; k < todo.size(); k++) {
                    AssetStore.Entry en = todo.get(k);
                    final int kk = k, nn = todo.size();
                    store.release();
                    Map<String, Object> a = store.asset(en.subset);
                    act.runOnUiThread(() -> status.setText("Building " + en.name + " …"));
                    Evaluator.SubsetReport rep = Evaluator.evaluate(a, (s, done, total) -> act.runOnUiThread(() -> {
                        bar.setProgress((int) (1000.0 * (kk + (double) done / total) / nn));
                        status.setText(en.name + ": " + done + " / " + total + " questions");
                    }), bm);
                    reps_.add(rep);
                    print(String.format(Locale.ROOT, "%-8s %6.2f %6.2f %5.1f %5.1f %6s %6s %6.1f%%",
                            rep.subset, rep.acc, rep.chrf, rep.r5, rep.ndcg10,
                            bm ? String.format(Locale.ROOT, "%.2f", rep.bmAcc) : "-",
                            bm ? String.format(Locale.ROOT, "%.2f", rep.bmChrf) : "-", rep.parityTop));
                    print(String.format(Locale.ROOT, "         python reference: acc %.2f, chrF %.2f · %.1f ms/question",
                            en.refAcc, en.refChrf, rep.msPerQuery));
                }
                store.release();
                if (reps_.size() > 1) {
                    act.runOnUiThread(() -> status.setText("Guarantee experiment: " + reps + " random calibration/test splits …"));
                    print("");
                    print("Error rate among answered questions (lenient, α = 20%, δ = 10%)");
                    print(String.format(Locale.ROOT, "%-8s | %6s %6s %6s | %6s %6s %6s", "subset", "cov", "risk", "viol", "cov", "risk", "viol"));
                    print(String.format(Locale.ROOT, "%-8s | %20s | %20s", "", "one pooled threshold", "per-language"));
                    for (Evaluator.GuaranteeRow g : Evaluator.guarantee(reps_, true, reps, 0.2, 0.1, 0)) {
                        print(String.format(Locale.ROOT, "%-8s | %5.1f%% %5.1f%% %5.1f%% | %5.1f%% %5.1f%% %5.1f%%", g.subset,
                                100 * g.pooledCoverage, 100 * g.pooledRisk, 100 * g.pooledViolation,
                                100 * g.langCoverage, 100 * g.langRisk, 100 * g.langViolation));
                    }
                    print("cov = share answered, risk = wrong among answered, viol = share of splits with risk > 20%.");
                    print("Paper: pooled threshold fails English (Ethiopia) with 25.6% wrong in 92% of splits;");
                    print("per-language thresholds stay under 20% (violations ≤ 2.3%).");
                }
                act.runOnUiThread(() -> { bar.setProgress(1000); status.setText("Done."); busy(false); });
            } catch (OutOfMemoryError oom) {
                store.release();
                act.runOnUiThread(() -> { status.setText("Not enough memory on this device for that subset."); busy(false); });
            } catch (Exception e) {
                act.runOnUiThread(() -> { status.setText("Error: " + e.getMessage()); busy(false); });
            }
        });
    }

    private void runAkan() {
        report.setLength(0);
        out.setText("");
        busy(true);
        exec.execute(() -> {
            try {
                store.release();
                Map<String, Object> a = store.asset("Aka_Gha");
                double[] r = Evaluator.robustness(a, Evaluator::akanKeyboard, (s, done, total) -> act.runOnUiThread(() -> {
                    bar.setProgress((int) (1000.0 * done / total));
                    status.setText("Akan: " + done + " / " + total + " questions, clean and without ɛ/ɔ");
                }));
                store.release();
                print("Akan (Ghana): chrF++ on clean vs keyboard-degraded questions");
                print(String.format(Locale.ROOT, "SANKOFA  %.2f -> %.2f", r[0], r[1]));
                print(String.format(Locale.ROOT, "BM25     %.2f -> %.2f", r[2], r[3]));
                print("Paper: SANKOFA 31.0 -> 31.0, BM25 29.5 -> 25.4");
                act.runOnUiThread(() -> { status.setText("Done."); busy(false); });
            } catch (Exception e) {
                act.runOnUiThread(() -> { status.setText("Error: " + e.getMessage()); busy(false); });
            }
        });
    }
}
