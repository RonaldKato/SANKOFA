"""Cross-lingual bridge experiment: does the English twin bank help local-language retrieval?
Regimes: full local bank, and few-paraphrase (1 training question per local answer cluster)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from sankofa.paths import DATA, RESULTS
import sys, json
import numpy as np, pandas as pd
from sankofa.retrieve import SankofaRetriever, VIEWS_ALL
from sankofa.fusion import learn_weights
from sankofa.metrics import evaluate, akey
from sankofa.xl import XLView
D=DATA; tr,va=pd.read_csv(D+"Train.csv"),pd.read_csv(D+"Val.csv")
cfg=dict(norm=True,scaffold=True,views=VIEWS_ALL)
rows=[]
for loc,eng in [("Swa_Ken","Eng_Ken"),("Lug_Uga","Eng_Uga"),("Aka_Gha","Eng_Gha"),("Amh_Eth","Eng_Eth")]:
    E=tr[tr.subset==eng]; V=va[va.subset==loc]; lang=loc[:3]
    for regime in ["full","few-paraphrase"]:
        T=tr[tr.subset==loc].copy()
        if regime=="few-paraphrase":
            T["k"]=T.output.map(akey); T=T.sample(frac=1,random_state=0).drop_duplicates("k")
        Q,A=T.input.tolist(),T.output.tolist()
        def builder(R):
            X=XLView(lang).fit(R,E.input.tolist(),E.output.tolist())
            return lambda qs: {"xl": X.scores(qs)}
        for use_xl in [False,True]:
            w,_=learn_weights(lang,Q,A,cfg,extra_builder=builder if use_xl else None)
            R=SankofaRetriever(lang,fusion="weighted",weights=w,**cfg).fit(Q,A)
            extra=builder(R)(V.input.tolist()) if use_xl else None
            top,_=R.predict(V.input.tolist(),extra=extra)
            m,_,_=evaluate([R.cluster_answer[c] for c in top],V.output.tolist())
            r=dict(subset=loc,regime=regime,xl=use_xl,n_train=len(T),w_xl=w.get("xl",0),**m)
            rows.append(r); print(r,flush=True)
pd.DataFrame(rows).to_csv(RESULTS+"xl_bridge.csv",index=False)
