"""Recommender-system view of vetted-answer QA.

Catalog = vetted answer clusters; a user's question = the context; the system recommends a ranked
list of answers. Q->Q views act like an item's interaction history (collaborative-style signal:
past questions that led to this item); Q->A views are content-based. We measure:
  (a) top-k ranking quality: Recall@1/5/10, MRR@10, nDCG@10
  (b) item cold-start: Recall@5 stratified by how many training questions an item has
  (c) popularity bias: catalog coverage@10, Gini of top-1 recommendations, popularity lift
  (d) conformal recommendation sets: per-language (Mondrian) vs pooled split-conformal lists
      that contain the vetted answer with probability >= 1 - alpha
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from sankofa.paths import DATA, RESULTS
import sys, pickle
import numpy as np, pandas as pd
from sankofa.retrieve import SankofaRetriever, VIEWS_ALL
from sankofa.fusion import learn_weights
from sankofa.metrics import akey

D = DATA; OUT = RESULTS
tr, va = pd.read_csv(D + "Train.csv"), pd.read_csv(D + "Val.csv")
store = pickle.load(open(OUT + "sankofa_store.pkl", "rb"))
BANK = ["Eng_Uga", "Lug_Uga", "Eng_Ken", "Swa_Ken", "Eng_Eth"]
SYS = {
    "Popularity (most-asked answers)": None,
    "BM25 (raw)": (dict(norm=False, scaffold=False, views=("qq_bm25",)), "rrf"),
    "History-only (Q->Q views)": (dict(norm=True, scaffold=True, views=("qq_char", "qq_word", "qq_bm25", "register")), "tuned"),
    "Content-only (Q->A views)": (dict(norm=True, scaffold=True, views=("qa_char", "qa_word")), "tuned"),
    "SANKOFA hybrid": (dict(norm=True, scaffold=True, views=VIEWS_ALL), "store"),
}


def gini(x):
    x = np.sort(np.asarray(x, float))
    if x.sum() == 0:
        return 0.0
    n = len(x)
    return float((2 * np.arange(1, n + 1) - n - 1).dot(x) / (n * x.sum()))


rank_rows, cold_rows, pop_rows, conf_data = [], [], [], {}
for s in BANK:
    lang = s[:3]; T, V = tr[tr.subset == s], va[va.subset == s]
    Q, A = T.input.tolist(), T.output.tolist()
    for name, spec in SYS.items():
        if spec is None:
            R = SankofaRetriever(lang, views=("qq_bm25",), norm=False, scaffold=False).fit(Q, A)
            pop = np.bincount(R.q2c, minlength=R.nc).astype(float)
            F = np.tile(pop / pop.max(), (len(V), 1))
        else:
            cfg, fus = spec
            if fus == "store":
                w = store[s]["weights"]
            elif fus == "tuned":
                w = learn_weights(lang, Q, A, cfg)[0]
            else:
                w = None
            R = SankofaRetriever(lang, fusion="weighted" if w else "rrf", weights=w, **cfg).fit(Q, A)
            F, _ = R.score(V.input.tolist())
            pop = np.bincount(R.q2c, minlength=R.nc).astype(float)
        idx = {akey(a): i for i, a in enumerate(R.cluster_answer)}
        gold = np.array([idx.get(akey(a), -1) for a in V.output])
        has = gold >= 0
        # rank of gold (1-based); ties broken pessimistically
        gs = np.where(has, F[np.arange(len(V)), np.maximum(gold, 0)], np.inf)
        rank = np.where(has, (F > gs[:, None]).sum(1) + (F == gs[:, None]).sum(1), 10 ** 9)
        rr = np.where(rank <= 10, 1.0 / rank, 0.0)
        ndcg = np.where(rank <= 10, 1.0 / np.log2(rank + 1), 0.0)
        rank_rows.append(dict(subset=s, system=name, n=len(V), ceiling=has.mean() * 100,
                              R1=(rank <= 1).mean() * 100, R5=(rank <= 5).mean() * 100, R10=(rank <= 10).mean() * 100,
                              MRR10=rr.mean() * 100, nDCG10=ndcg.mean() * 100))
        # cold start strata on gold-item popularity (number of training questions)
        gp = np.where(has, pop[np.maximum(gold, 0)], -1)
        for lab, lo, hi in [("1 question", 1, 1), ("2-4 questions", 2, 4), ("5+ questions", 5, 10 ** 9)]:
            m = (gp >= lo) & (gp <= hi)
            if m.sum():
                cold_rows.append(dict(subset=s, system=name, stratum=lab, n=int(m.sum()), R5=(rank[m] <= 5).mean() * 100))
        # popularity bias / coverage
        top10 = np.argsort(-F, 1)[:, :10]; top1 = top10[:, 0]
        cnt1 = np.bincount(top1, minlength=R.nc)
        gcnt = np.bincount(gold[has], minlength=R.nc)
        pop_rows.append(dict(subset=s, system=name, coverage10=len(np.unique(top10)) / R.nc * 100,
                             gini_top1=gini(cnt1), gini_gold=gini(gcnt),
                             pop_lift=pop[top1].mean() / pop[gold[has]].mean()))
        if name == "SANKOFA hybrid":
            Fn = F / np.maximum(F.max(1, keepdims=True), 1e-9)
            conf_data[s] = dict(Fn=Fn, gold=gold)
        print(s, name, {k: round(v, 1) for k, v in rank_rows[-1].items() if isinstance(v, float)}, flush=True)

# (d) conformal recommendation sets
ALPHA, REPS = 0.2, 300
rng = np.random.default_rng(0)
crow = []
for rep in range(REPS):
    cal, tst = {}, {}
    for s in BANK:
        p = rng.permutation(len(conf_data[s]["gold"])); cal[s], tst[s] = p[: len(p) // 2], p[len(p) // 2:]
    def ncs(s, ix):
        d = conf_data[s]; g = d["gold"][ix]
        return np.where(g >= 0, 1 - d["Fn"][ix, np.maximum(g, 0)], np.inf)
    def qhat(sc):
        n = len(sc); k = int(np.ceil((n + 1) * (1 - ALPHA)))
        return np.inf if k > n else np.sort(sc)[k - 1]
    qg = qhat(np.concatenate([ncs(s, cal[s]) for s in BANK]))
    for s in BANK:
        qm = qhat(ncs(s, cal[s]))
        d = conf_data[s]
        for pol, q in [("pooled", qg), ("per-language", qm)]:
            Fn = d["Fn"][tst[s]]
            size = (1 - Fn <= q).sum(1) if np.isfinite(q) else np.full(len(tst[s]), Fn.shape[1])
            g = d["gold"][tst[s]]
            hit = (g >= 0) & (1 - Fn[np.arange(len(g)), np.maximum(g, 0)] <= q)
            crow.append(dict(rep=rep, subset=s, policy=pol, coverage=hit.mean(), mean_size=size.mean(),
                             median_size=np.median(size), catalog=Fn.shape[1], under=float(hit.mean() < 1 - ALPHA)))
pd.DataFrame(rank_rows).to_csv(OUT + "recsys_rank.csv", index=False)
pd.DataFrame(cold_rows).to_csv(OUT + "recsys_cold.csv", index=False)
pd.DataFrame(pop_rows).to_csv(OUT + "recsys_pop.csv", index=False)
c = pd.DataFrame(crow)
cs = c.groupby(["subset", "policy"])[["coverage", "mean_size", "median_size", "catalog", "under"]].mean().round(3)
cs.to_csv(OUT + "recsys_conformal.csv"); print(cs.to_string())
