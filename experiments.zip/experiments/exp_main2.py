"""Main benchmark on official Val: baselines vs SANKOFA (self-tuned fusion) + ablations.
Saves per-query results for significance tests and confidence/abstention experiments."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from sankofa.paths import DATA, RESULTS
import sys, time, pickle, os
import numpy as np, pandas as pd
from sankofa.retrieve import SankofaRetriever, VIEWS_ALL
from sankofa.fusion import learn_weights
from sankofa.metrics import evaluate

D = DATA; OUT = RESULTS
tr, va = pd.read_csv(D + "Train.csv"), pd.read_csv(D + "Val.csv")
SUBSETS = sorted(tr.subset.unique())
rng = np.random.default_rng(0)
NOREG = tuple(v for v in VIEWS_ALL if v != "register")
SYSTEMS = {
    "BM25 (raw)":                   (dict(norm=False, scaffold=False, views=("qq_bm25",)), None),
    "TF-IDF word (raw)":            (dict(norm=False, scaffold=False, views=("qq_word",)), None),
    "SANKOFA (full)":               (dict(norm=True, scaffold=True, views=VIEWS_ALL), "tuned"),
    "- self-tuned fusion (use RRF)": (dict(norm=True, scaffold=True, views=VIEWS_ALL), "rrf"),
    "- script/keyboard norm":       (dict(norm=False, scaffold=True, views=VIEWS_ALL), "tuned"),
    "- register view":              (dict(norm=True, scaffold=True, views=NOREG), "tuned"),
    "- scaffold factorisation":     (dict(norm=True, scaffold=False, views=NOREG), "tuned"),
    "- answer views (Q->A)":        (dict(norm=True, scaffold=True, views=("qq_char", "qq_word", "qq_bm25", "register")), "tuned"),
    "- char n-gram views":          (dict(norm=True, scaffold=True, views=("qq_word", "qq_bm25", "qa_word", "register")), "tuned"),
}
rows, perq, store = [], {}, {}
for s in SUBSETS:
    lang = s[:3]
    T, V = tr[tr.subset == s], va[va.subset == s]
    Q, A, VQ, VA = T.input.tolist(), T.output.tolist(), V.input.tolist(), V.output.tolist()
    rnd = [A[i] for i in rng.integers(0, len(A), len(V))]
    maj = [T.output.value_counts().index[0]] * len(V)
    for name, preds in [("Random bank answer", rnd), ("Most-frequent answer", maj)]:
        m, a_, c_ = evaluate(preds, VA); rows.append(dict(system=name, subset=s, **m)); perq[(name, s)] = (a_, c_)
    for name, (cfg, fus) in SYSTEMS.items():
        t0 = time.time()
        w, dev_info = None, None
        if fus == "tuned":
            w, _, dev_info = learn_weights(lang, Q, A, cfg)
        t_fit0 = time.time()
        R = SankofaRetriever(lang, fusion="weighted" if fus == "tuned" else "rrf", weights=w, **cfg).fit(Q, A)
        t_fit = time.time() - t_fit0
        t_q0 = time.time()
        top, feats = R.predict(VQ)
        ms = (time.time() - t_q0) / len(VQ) * 1000
        preds = [R.cluster_answer[c] for c in top]
        m, a_, c_ = evaluate(preds, VA)
        rows.append(dict(system=name, subset=s, ms_per_query=ms, fit_s=t_fit, tune_s=t_fit0 - t0, **m))
        perq[(name, s)] = (a_, c_)
        if name == "SANKOFA (full)":
            store[s] = dict(weights=w, dev_info=dev_info, val_feats=feats, val_exact=a_, val_chrf=c_,
                            val_pred=preds, n_clusters=R.nc, n_bank_q=len(Q),
                            index_bytes=len(pickle.dumps(R)))
        print(s, name, {k: round(v, 2) for k, v in m.items()}, f"{ms:.2f}ms/q", flush=True)

df = pd.DataFrame(rows); df.to_csv(OUT + "main2_val.csv", index=False)
pickle.dump(perq, open(OUT + "main2_perq.pkl", "wb"))
pickle.dump(store, open(OUT + "sankofa_store.pkl", "wb"))
macro = df.groupby("system", sort=False)[["acc", "chrf", "rougeL"]].mean().round(2)
print(macro); macro.to_csv(OUT + "main2_macro.csv")
