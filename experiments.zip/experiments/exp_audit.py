"""Translation-drift audit on mined English<->local twins: flag numeric / entity disagreement."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from sankofa.paths import DATA, RESULTS
import sys, re, json, numpy as np, pandas as pd
from sankofa.bridge import Bridge
from sankofa.xl import cluster_docs
tr=pd.read_csv(DATA+'Train.csv')
num=lambda s: sorted(re.findall(r'\d+(?:[.,]\d+)?', s.replace(' ','')))
ent=lambda s: set(x.lower() for x in re.findall(r'\b[A-Z][A-Za-z]*[A-Z0-9][A-Za-z0-9-]*\b|\b[A-Z][a-z]+(?:in|ine|ol|ide|one|cin|vir)\b', s))
out={}
for e,l in [('Eng_Ken','Swa_Ken'),('Eng_Uga','Lug_Uga'),('Eng_Gha','Aka_Gha'),('Eng_Eth','Amh_Eth')]:
    Ea,Eq=cluster_docs(tr[tr.subset==e].input,tr[tr.subset==e].output)
    La,Lq=cluster_docs(tr[tr.subset==l].input,tr[tr.subset==l].output)
    B=Bridge(l[:3]).fit([a+' '+' '.join(q) for a,q in zip(Ea,Eq)],[a+' '+' '.join(q) for a,q in zip(La,Lq)])
    flags=[]
    for i,j,s in B.pairs:
        ne,nl=num(Ea[i]),num(La[j])
        if ne and nl and ne!=nl:
            flags.append(dict(type='number',score=round(s,3),eng=Ea[i],loc=La[j],eng_nums=ne,loc_nums=nl))
    out[l]=dict(pairs=len(B.pairs),flags=flags)
    print('####',l,'pairs',len(B.pairs),'number flags',len(flags))
    for f in sorted(flags,key=lambda f:-f['score'])[:12]:
        print(f['score'],f['eng_nums'],f['loc_nums'],'\n   E:',f['eng'][:300],'\n   L:',f['loc'][:300])
json.dump(out,open(RESULTS+'audit_flags.json','w'),ensure_ascii=False,indent=1)
