"""Answer-or-escalate experiment: global vs language-conditional (Mondrian) Learn-then-Test.
Conditions: full bank, and 'knowledge-gap' bank (20% of answer clusters removed)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from sankofa.paths import DATA, RESULTS
import sys, pickle
import numpy as np, pandas as pd
from sankofa.retrieve import SankofaRetriever, VIEWS_ALL
from sankofa.fusion import learn_weights
from sankofa.metrics import evaluate, akey
from sankofa.abstain import feat_matrix, ConfidenceModel, ltt_threshold

D = DATA; OUT = RESULTS
tr, va = pd.read_csv(D + "Train.csv"), pd.read_csv(D + "Val.csv")
SUBSETS = sorted(tr.subset.unique())
cfg = dict(norm=True, scaffold=True, views=VIEWS_ALL)
ALPHA, DELTA, REPS = 0.2, 0.1, 300
import os
GRID = np.round(np.arange(0.30, 0.951, 0.05), 2) if os.environ.get("GRID") == "coarse" else None
TAG = "_coarse" if GRID is not None else ""
CRITERIA = {"strict": lambda ex, cf: ex.astype(bool), "lenient": lambda ex, cf: (ex.astype(bool)) | (cf >= 50)}

store = pickle.load(open(OUT + "sankofa_store.pkl", "rb"))
data = {}
for cond in ["full bank", "knowledge gap (-20% clusters)"]:
    for s in SUBSETS:
        lang = s[:3]
        T, V = tr[tr.subset == s].copy(), va[va.subset == s]
        if cond == "full bank":
            st = store[s]; w, dev, feats, ex, cf = st["weights"], st["dev_info"], st["val_feats"], st["val_exact"], st["val_chrf"]
        else:
            T["k"] = T.output.map(akey)
            keys = T.k.unique(); r = np.random.default_rng(1); drop = set(r.choice(keys, int(0.2 * len(keys)), replace=False))
            T = T[~T.k.isin(drop)]
            w, _, dev = learn_weights(lang, T.input.tolist(), T.output.tolist(), cfg)
            R = SankofaRetriever(lang, fusion="weighted", weights=w, **cfg).fit(T.input.tolist(), T.output.tolist())
            top, feats = R.predict(V.input.tolist())
            m, ex, cf = evaluate([R.cluster_answer[c] for c in top], V.output.tolist())
        Xd, Xv = feat_matrix(dev["feats"], w), feat_matrix(feats, w)
        data[(cond, s)] = dict(Xd=Xd, Xv=Xv, dev_exact=dev["exact"].astype(float), dev_chrf=dev["chrf"], ex=np.asarray(ex), cf=np.asarray(cf))
        print(cond, s, "val strict acc", np.mean(ex).round(3), flush=True)

rows = []
for cond in ["full bank", "knowledge gap (-20% clusters)"]:
    for crit, fn in CRITERIA.items():
        conf, wrong = {}, {}
        for s in SUBSETS:
            d = data[(cond, s)]
            ytr = fn(d["dev_exact"], d["dev_chrf"]).astype(float)
            cm = ConfidenceModel().fit(d["Xd"], ytr)
            conf[s] = cm.predict(d["Xv"]); wrong[s] = ~fn(d["ex"], d["cf"])
        rng = np.random.default_rng(0)
        for rep in range(REPS):
            split = {s: rng.permutation(len(conf[s])) for s in SUBSETS}
            cal = {s: split[s][: len(split[s]) // 2] for s in SUBSETS}
            tst = {s: split[s][len(split[s]) // 2:] for s in SUBSETS}
            # global: one threshold from pooled calibration data
            lam_g = ltt_threshold(np.concatenate([conf[s][cal[s]] for s in SUBSETS]),
                                  np.concatenate([wrong[s][cal[s]] for s in SUBSETS]), ALPHA, DELTA, GRID)
            for s in SUBSETS:
                lam_m = ltt_threshold(conf[s][cal[s]], wrong[s][cal[s]], ALPHA, DELTA, GRID)
                for policy, lam in [("global", lam_g), ("mondrian", lam_m), ("always answer", -np.inf)]:
                    ans = conf[s][tst[s]] >= lam
                    n = ans.sum()
                    risk = wrong[s][tst[s]][ans].mean() if n else 0.0
                    rows.append(dict(cond=cond, crit=crit, rep=rep, subset=s, policy=policy,
                                     coverage=ans.mean(), risk=risk, answered=n, violate=float(risk > ALPHA)))
    print("done", cond, flush=True)
df = pd.DataFrame(rows); df.to_csv(OUT + f"abstain_runs{TAG}.csv.gz", index=False)
summ = df.groupby(["cond", "crit", "policy", "subset"])[["coverage", "risk", "violate"]].mean().round(3)
summ.to_csv(OUT + f"abstain_summary{TAG}.csv"); print(summ.to_string())
