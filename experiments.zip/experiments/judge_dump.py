import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from sankofa.paths import DATA, RESULTS
import sys, numpy as np, pandas as pd, re, pickle
from sankofa.bridge import Bridge
from sankofa.metrics import akey
tr=pd.read_csv(DATA+'Train.csv')
def docs(sub):
    T=tr[tr.subset==sub].copy(); T['k']=T.output.map(akey)
    g=T.groupby('k',sort=False)
    return [d.output.iloc[0] for _,d in g],[d.output.iloc[0]+' '+' '.join(d.input) for _,d in g]
out={}
for e,l in [('Eng_Ken','Swa_Ken'),('Eng_Uga','Lug_Uga'),('Eng_Gha','Aka_Gha'),('Eng_Eth','Amh_Eth')]:
    Ea,Ed=docs(e); La,Ld=docs(l); B=Bridge(l[:3]).fit(Ed,Ld)
    # digit-signature agreement proxy
    dig=lambda s: tuple(sorted(set(re.findall(r'\d+',s))))
    both=[(i,j) for i,j,_ in B.pairs if dig(Ea[i]) and dig(La[j])]
    agree=np.mean([dig(Ea[i])==dig(La[j]) for i,j in both]) if both else float('nan')
    rng=np.random.default_rng(7); idx=rng.choice(len(B.pairs),25,replace=False)
    samp=[(int(k),Ea[B.pairs[k][0]][:140],La[B.pairs[k][1]][:140],round(B.pairs[k][2],2)) for k in idx]
    out[l]=dict(history=B.history,n_e=len(Ea),n_l=len(La),digit_n=len(both),digit_agree=agree,sample=samp,
                scores=[p[2] for p in B.pairs], lexsize=len(B.lex), anchors=len(B.anchors))
    print('#####',e,l,'digit pairs',len(both),'agree',round(agree,3))
    for n,(k,a,b,s) in enumerate(samp): print(n,s,'| E:',a,'\n      | L:',b)
pickle.dump(out,open(RESULTS+'bridge_dump.pkl','wb'))
