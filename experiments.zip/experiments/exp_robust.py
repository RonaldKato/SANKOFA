"""Keyboard-reality robustness: how do systems degrade when users type the way phones let them?
P1 (script-specific): Akan without ɛ/ɔ keys; Amharic homophone-letter substitution;
    Luganda apostrophes dropped / curly; (English/Swahili: not applicable -> P2 only)
P2 (SMS-style, all languages): lowercase, punctuation dropped, 3% adjacent-character swaps."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from sankofa.paths import DATA, RESULTS
import sys, pickle, re
import numpy as np, pandas as pd
from sankofa.retrieve import SankofaRetriever, VIEWS_ALL
from sankofa.fusion import learn_weights
from sankofa.metrics import evaluate

D = DATA; OUT = RESULTS
tr, va = pd.read_csv(D + "Train.csv"), pd.read_csv(D + "Val.csv")
store = pickle.load(open(OUT + "sankofa_store.pkl", "rb"))
FAM = [(0x1200, 0x1210, 0x1280), (0x1230, 0x1220), (0x12A0, 0x12D0), (0x1338, 0x1340)]
FMAP = {}
for fam in FAM:
    for b in fam:
        FMAP[b] = fam


def p1(q, lang, rng):
    if lang == "Aka":
        return q.replace("ɛ", "e").replace("ɔ", "o").replace("Ɛ", "E").replace("Ɔ", "O")
    if lang == "Amh":
        out = []
        for c in q:
            cp = ord(c)
            if 0x1200 <= cp < 0x1360:
                off = (cp - 0x1200) % 8; base = cp - off
                if base in FMAP and rng.random() < 0.5:
                    c = chr(rng.choice(FMAP[base]) + off)
            out.append(c)
        return "".join(out)
    if lang == "Lug":
        return "".join(("" if rng.random() < 0.5 else "’") if ch in "'’" else ch for ch in q)
    return q


def p2(q, lang, rng):
    q = re.sub(r"[^\w\s]", " ", q.lower())
    q = list(re.sub(r"\s+", " ", q).strip())
    for i in range(len(q) - 1):
        if q[i] != " " and q[i + 1] != " " and rng.random() < 0.03:
            q[i], q[i + 1] = q[i + 1], q[i]
    return "".join(q)


SYS = {"BM25 (raw)": (dict(norm=False, scaffold=False, views=("qq_bm25",)), None),
       "SANKOFA - norm": (dict(norm=False, scaffold=True, views=VIEWS_ALL), "tuned"),
       "SANKOFA (full)": (dict(norm=True, scaffold=True, views=VIEWS_ALL), "store")}
rows = []
for s in sorted(tr.subset.unique()):
    lang = s[:3]; T, V = tr[tr.subset == s], va[va.subset == s]
    Q, A = T.input.tolist(), T.output.tolist()
    for name, (cfg, fus) in SYS.items():
        w = store[s]["weights"] if fus == "store" else (learn_weights(lang, Q, A, cfg)[0] if fus == "tuned" else None)
        R = SankofaRetriever(lang, fusion="weighted" if w else "rrf", weights=w, **cfg).fit(Q, A)
        for pert in ["clean", "P1 script/keyboard", "P2 SMS-style"]:
            if pert == "P1 script/keyboard" and lang not in ("Aka", "Amh", "Lug"):
                continue
            rng = np.random.default_rng(0)
            qs = V.input.tolist() if pert == "clean" else [(p1 if pert.startswith("P1") else p2)(q, lang, rng) for q in V.input]
            top, _ = R.predict(qs)
            m, _, _ = evaluate([R.cluster_answer[c] for c in top], V.output.tolist())
            rows.append(dict(subset=s, system=name, perturbation=pert, **m))
            print(s, name, pert, round(m["acc"], 2), round(m["chrf"], 2), flush=True)
pd.DataFrame(rows).to_csv(OUT + "robust.csv", index=False)
