import numpy as np
from sacrebleu.metrics import CHRF

_chrf = CHRF(word_order=2)  # chrF++


def akey(a):
    return " ".join(str(a).split()).strip()


def chrf(h, r):
    return _chrf.sentence_score(h, [r]).score


def rouge_l(h, r):
    """Whitespace-token ROUGE-L F1 (script-agnostic: works for Ge'ez too)."""
    x, y = str(h).lower().split(), str(r).lower().split()
    if not x or not y:
        return 0.0
    prev = [0] * (len(y) + 1)
    for xi in x:
        cur = [0]
        for j, yj in enumerate(y):
            cur.append(prev[j] + 1 if xi == yj else max(prev[j + 1], cur[j]))
        prev = cur
    l = prev[-1]
    p, rr = l / len(x), l / len(y)
    return 0.0 if l == 0 else 100 * 2 * p * rr / (p + rr)


def evaluate(preds, refs):
    acc = np.array([akey(p) == akey(r) for p, r in zip(preds, refs)], float)
    cf = np.array([chrf(p, r) for p, r in zip(preds, refs)])
    rl = np.array([rouge_l(p, r) for p, r in zip(preds, refs)])
    return dict(acc=100 * acc.mean(), chrf=cf.mean(), rougeL=rl.mean(), n=len(refs)), acc, cf
