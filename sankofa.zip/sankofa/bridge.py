"""Anchor-bootstrapped mining of a pseudo-parallel corpus from *comparable* monolingual
QA banks (English <-> local language from the same country), with no MT system, no
pretrained model and no seed dictionary.

Round 0  : shared 'anchor' strings (numbers, acronyms, drug names, loanwords, code-switched
           English) + a length-ratio prior  ->  mutual-nearest-neighbour (MNN) pairs.
Round k  : induce a bilingual lexicon from current pairs with the Dice coefficient,
           translate each local document into a weighted English bag of words, re-score,
           re-mine MNN pairs. Repeat.
"""
import re
from collections import Counter, defaultdict
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

from .normalize import normalize

TOK = re.compile(r"[^\W_]+(?:[-'][^\W_]+)*", re.U)


def toks(s, lang):
    return TOK.findall(normalize(s, lang, eth_decompose=False))


def _mnn(S, thr):
    i2 = S.argmax(1)
    j2 = S.argmax(0)
    return [(i, int(i2[i]), float(S[i, i2[i]])) for i in range(S.shape[0])
            if j2[i2[i]] == i and S[i, i2[i]] > thr]


def induce_lexicon(pairs, E_toks, L_toks, min_co=2, min_dice=0.15, topk=3):
    ce, cl, co = Counter(), Counter(), Counter()
    for i, j, _ in pairs:
        se, sl = set(E_toks[i]), set(L_toks[j])
        ce.update(se); cl.update(sl)
        for l in sl:
            for e in se:
                co[(l, e)] += 1
    by_l = defaultdict(list)
    for (l, e), c in co.items():
        if c < min_co:
            continue
        d = 2 * c / (cl[l] + ce[e])
        if d >= min_dice:
            by_l[l].append((d, e))
    return {l: sorted(v, reverse=True)[:topk] for l, v in by_l.items()}


def translate_bow(tokens, lex):
    out = []
    for t in tokens:
        for d, e in lex.get(t, []):
            out.extend([e] * max(1, int(round(3 * d))))
    return " ".join(out)


class Bridge:
    def __init__(self, loc_lang, rounds=4, thr0=0.15, thr=0.2):
        self.loc_lang, self.rounds, self.thr0, self.thr = loc_lang, rounds, thr0, thr

    def fit(self, E_docs, L_docs):
        """E_docs / L_docs: lists of documents (answer + its questions) per cluster."""
        Et = [toks(d, "Eng") for d in E_docs]
        Lt = [toks(d, self.loc_lang) for d in L_docs]
        le = np.array([len(x) for x in Et]) + 1
        ll = np.array([len(x) for x in Lt]) + 1
        r = np.median([np.log(b / a) for a, b in zip(le, ll)]) if False else 0.0
        # language-pair length ratio estimated from corpus means (robust to unpaired data)
        self.len_ratio = np.log(ll.mean() / le.mean())
        P = np.exp(-1.5 * np.abs(np.log(ll[None, :] / le[:, None]) - self.len_ratio))
        # ---- round 0: anchors
        ve = set(t for x in Et for t in x)
        vl = set(t for x in Lt for t in x)
        shared = (ve & vl)
        self.anchors = shared
        av = TfidfVectorizer(analyzer=lambda x: x, sublinear_tf=True)
        av.fit([[t for t in x if t in shared] for x in Et + Lt])
        A = (av.transform([[t for t in x if t in shared] for x in Et])
             @ av.transform([[t for t in x if t in shared] for x in Lt]).T).toarray()
        S = A * P
        pairs = _mnn(S, self.thr0)
        self.history = [dict(round=0, pairs=len(pairs), lex=0)]
        # ---- bootstrapping rounds
        wv = TfidfVectorizer(analyzer=lambda x: x, sublinear_tf=True).fit(Et)
        XE = wv.transform(Et)
        for k in range(1, self.rounds + 1):
            lex = induce_lexicon(pairs, Et, Lt)
            # identical strings are always candidate translations
            for t in shared:
                lex.setdefault(t, [(1.0, t)])
            XL = wv.transform([translate_bow(x, lex).split() for x in Lt])
            L = (XE @ XL.T).toarray()
            S = (0.7 * L + 0.3 * A) * P
            pairs = _mnn(S, self.thr)
            self.history.append(dict(round=k, pairs=len(pairs), lex=len(lex)))
        self.lex, self.pairs, self.S = lex, pairs, S
        self.Et, self.Lt, self.wv = Et, Lt, wv
        return self

    def translate_queries(self, queries):
        return self.wv.transform([translate_bow(toks(q, self.loc_lang), self.lex).split() for q in queries])
