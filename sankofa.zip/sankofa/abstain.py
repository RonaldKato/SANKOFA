"""Answer-or-escalate with a finite-sample guarantee.

Learn-then-Test (Angelopoulos et al., 2021) with fixed-sequence testing: choose the most
permissive confidence threshold lambda such that, with probability >= 1 - delta over the
calibration draw, the error rate among *answered* questions is <= alpha. Calibrating this
separately per language (Mondrian) gives the guarantee for every language, not just on
average."""
import numpy as np
from scipy.stats import binom
from sklearn.linear_model import LogisticRegression

FEATS = ["top_n", "margin_n", "agree", "sim_qq_char", "sim_qq_word", "sim_qq_bm25",
         "sim_qa_char", "sim_qa_word", "sim_register"]


def feat_matrix(feats, weights):
    tot = sum(weights.values()) or 1.0
    f = dict(feats)
    f["top_n"] = f["top"] / tot
    f["margin_n"] = f["margin"] / tot
    n = len(f["top"])
    return np.column_stack([f.get(k, np.zeros(n)) for k in FEATS])


class ConfidenceModel:
    def fit(self, X, y):
        self.const = None
        if y.sum() < 5 or (1 - y).sum() < 5:
            self.const = float(y.mean())
            return self
        self.m = LogisticRegression(C=1.0, max_iter=2000).fit(X, y)
        return self

    def predict(self, X):
        if self.const is not None:
            return np.full(len(X), self.const)
        return self.m.predict_proba(X)[:, 1]


def ltt_threshold(conf, wrong, alpha=0.2, delta=0.1, grid=None):
    """Learn-then-Test with a Bonferroni family over a FIXED threshold grid (independent of the data).
    Every lambda whose binomial p-value for H0: P(wrong | conf >= lambda) > alpha is <= delta/|grid|
    is certified; return the most permissive certified lambda (inf = escalate everything)."""
    if grid is None:
        grid = np.round(np.arange(0.02, 1.0, 0.02), 2)
    lam_ok = np.inf
    for lam in grid:
        ans = conf >= lam
        n = int(ans.sum())
        if n == 0:
            continue
        k = int(wrong[ans].sum())
        if binom.cdf(k, n, alpha) <= delta / len(grid):
            lam_ok = min(lam_ok, lam)
    return lam_ok
