"""Script- and keyboard-aware normalization for African-language health QA.

Components
----------
* Unicode/apostrophe/punctuation unification (all languages)
* Ge'ez (Ethiopic) homophone folding + syllable decomposition (Amharic)
* Akan open-vowel folding (ɛ->e, ɔ->o) to survive phone keyboards
* Paraphrase-invariant scaffold mining and stripping (all languages)
"""
import re
import unicodedata
from collections import Counter, defaultdict

APOS = dict.fromkeys(map(ord, "’‘ʼ`´′"), "'")
ETH_PUNCT = {"።": " . ", "፣": " , ", "፤": " ; ", "፥": " : ",
             "፦": " : ", "፧": " ? ", "፡": " "}

# Ethiopic homophone series (same sound in modern Amharic, different letters).
# Each value is the first code point (1st order) of an 8-slot series.
_ETH_HOMOPHONE = {0x1210: 0x1200, 0x1280: 0x1200,   # ሐ ኀ -> ሀ
                  0x1220: 0x1230,                   # ሠ -> ሰ
                  0x12D0: 0x12A0,                   # ዐ -> አ
                  0x1340: 0x1338}                   # ፀ -> ጸ
_VOWELS = ["e", "u", "i", "a", "E", "", "o", "W"]  # Ge'ez orders 1..8 (6th = bare consonant / schwa)


def _eth_char(c, fold=True, decompose=True):
    cp = ord(c)
    if not (0x1200 <= cp <= 0x137F) or cp >= 0x1360:
        return c
    off = (cp - 0x1200) % 8
    base = cp - off
    if fold and base in _ETH_HOMOPHONE:
        base = _ETH_HOMOPHONE[base]
    if not decompose:
        return chr(base + off)
    return chr(base + 5) + _VOWELS[off]  # 6th-order form = consonant, then vowel letter


def normalize(text, lang, eth_fold=True, eth_decompose=True, akan_fold=True):
    if not isinstance(text, str):
        return ""
    t = unicodedata.normalize("NFC", text).translate(APOS).lower()
    if lang == "Amh":
        for k, v in ETH_PUNCT.items():
            t = t.replace(k, v)
        t = "".join(_eth_char(c, eth_fold, eth_decompose) for c in t)
    if lang == "Aka" and akan_fold:
        t = t.replace("ɛ", "e").replace("ɔ", "o")
    t = re.sub(r"[\"“”«»()\[\]]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


# ---------------------------------------------------------------------------
# Scaffold mining: an affix is a *scaffold* if (i) it is frequent and (ii) the
# remainders it wraps also occur with a different affix or bare, i.e. the affix
# is paraphrase-invariant packaging rather than content.
# ---------------------------------------------------------------------------
def _words(s):
    return s.split()


def mine_scaffolds(questions, min_frac=0.01, min_count=20, max_n=8, min_reuse=0.3):
    """Mine paraphrase-invariant scaffolds from *original-case* questions.

    suffix scaffold: begins right after a punctuation boundary (?,.:) -> appended instruction
    prefix scaffold: is followed by an embedded question (remainder starts with a capitalised
                     word that is itself a frequent question opener in this subset)
    plus: frequent (>= max(min_count, min_frac*N)) and the wrapped remainders re-occur
    with another affix or bare (paraphrase reuse >= min_reuse).
    """
    qs = [q.strip() for q in questions if isinstance(q, str) and q.strip()]
    n = len(qs)
    thr = max(min_count, int(min_frac * n))
    openers = Counter(_words(q)[0] for q in qs if _words(q))
    openers = {w for w, c in openers.items() if c >= thr and w[:1].isupper()}
    key = lambda r: r.lower().strip(" ,.?")
    found = {}
    for side in ("prefix", "suffix"):
        rem_by_affix = defaultdict(list)
        for q in qs:
            w = _words(q)
            for k in range(1, min(max_n, len(w) - 2) + 1):
                if side == "suffix":
                    if not re.search(r"[?,.:]$", w[-k - 1]):
                        continue
                    aff, rem = " ".join(w[-k:]), " ".join(w[:-k])
                else:
                    if w[k] not in openers:
                        continue
                    aff, rem = " ".join(w[:k]), " ".join(w[k:])
                rem_by_affix[aff].append(key(rem))
        bare = Counter(key(q) for q in qs)
        seen = Counter()
        for rems in rem_by_affix.values():
            for r in set(rems):
                seen[r] += 1
        kept = []
        for aff, rems in rem_by_affix.items():
            if len(rems) < thr:
                continue
            reuse = sum(1 for r in rems if seen[r] > 1 or bare[r] > 0) / len(rems)
            if reuse >= min_reuse:
                kept.append((aff, len(rems), reuse))
        kept.sort(key=lambda x: -x[1])
        found[side] = kept
    found["openers"] = openers
    return found


def _canon(t):
    return " ".join(re.sub(r"[^\w\s]", " ", t.lower()).split())


def split_scaffold(q, scaffolds, fuzz=0.85):
    """Return (core, register). Mined scaffolds are matched punctuation-insensitively and with
    typo tolerance (SequenceMatcher ratio >= fuzz on the canonical tail), so SMS-style input
    ('please answr in detail' with no '?,') is still recognised."""
    from difflib import SequenceMatcher
    q = q.strip() if isinstance(q, str) else ""
    cq = _canon(q)
    for aff, _, _ in sorted(scaffolds.get("suffix", []), key=lambda x: -len(x[0])):
        ca = _canon(aff)
        if not ca or len(cq) <= len(ca) + 3:
            continue
        tail = cq[-len(ca):]
        if tail == ca or SequenceMatcher(None, tail, ca).ratio() >= fuzz:
            # cut the same number of canonical words from the original string
            nw = len(ca.split())
            words = q.split()
            core = " ".join(words[:-nw]) if len(words) > nw else q
            return core.rstrip(" ,.;:"), ca
    for aff, _, _ in sorted(scaffolds.get("prefix", []), key=lambda x: -len(x[0])):
        if q.startswith(aff + " "):
            rest = q[len(aff):].strip()
            if rest.split() and rest.split()[0] in scaffolds.get("openers", ()):
                return rest, _canon(aff)
    return q, ""


def strip_scaffolds(q, scaffolds):
    return split_scaffold(q, scaffolds)[0]
