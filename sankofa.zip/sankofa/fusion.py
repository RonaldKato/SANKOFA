"""Self-tuned per-language view fusion (no access to Val/Test).

Objective on an internal dev split of TRAIN: mean 'soft correctness' of the chosen
cluster, where soft = 1 for the exact vetted answer, else char-TF-IDF cosine between
chosen and gold answer. Works for both answer-bank languages (exact matches exist) and
open-answer languages (no exact match possible)."""
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from .retrieve import SankofaRetriever
from .metrics import akey

GRID = [0.0, 0.25, 0.5, 1.0, 2.0, 4.0]


def soft_target(R, gold_answers):
    v = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4), sublinear_tf=True)
    v.fit(R.cluster_answer + list(gold_answers))
    G = (v.transform(list(gold_answers)) @ v.transform(R.cluster_answer).T).toarray()
    idx = {akey(a): i for i, a in enumerate(R.cluster_answer)}
    for i, g in enumerate(gold_answers):
        j = idx.get(akey(g))
        if j is not None:
            G[i, :] = np.minimum(G[i, :], 0.99)
            G[i, j] = 1.0
    return G


def learn_weights(lang, questions, answers, cfg, dev_frac=0.15, seed=0, passes=3, extra_builder=None):
    rng = np.random.default_rng(seed)
    n = len(questions)
    perm = rng.permutation(n)
    dev, fit = perm[: int(dev_frac * n)], perm[int(dev_frac * n):]
    q, a = np.array(questions, dtype=object), np.array(answers, dtype=object)
    R = SankofaRetriever(lang, fusion="weighted", **cfg).fit(list(q[fit]), list(a[fit]))
    sc = R.view_scores(list(q[dev]))
    if extra_builder is not None:
        sc.update(extra_builder(R)(list(q[dev])))
    G = soft_target(R, list(a[dev]))
    rows = np.arange(len(dev))
    views = list(sc)
    obj = lambda w: G[rows, sum(w[v] * sc[v] for v in views).argmax(1)].mean()
    # init: best single view
    best_v = max(views, key=lambda v: G[rows, sc[v].argmax(1)].mean())
    w = {v: (1.0 if v == best_v else 0.0) for v in views}
    best = obj(w)
    for _ in range(passes):
        improved = False
        for v in views:
            for g in GRID:
                if g == w[v]:
                    continue
                cand = dict(w, **{v: g})
                if sum(cand.values()) == 0:
                    continue
                o = obj(cand)
                if o > best + 1e-6:
                    best, w, improved = o, cand, True
        if not improved:
            break
    # dev-set predictions with the learned weights -> training data for the confidence model
    R.weights = w
    top, feats = R.predict(None, sc=sc)
    from .metrics import chrf
    dev_info = dict(feats=feats, exact=(G[rows, top] >= 1.0),
                    chrf=np.array([chrf(R.cluster_answer[t], g) for t, g in zip(top, a[dev])]))
    return w, best, dev_info
