"""Dual-view, multi-granularity retrieval over a vetted answer bank (CPU-only)."""
import numpy as np
import scipy.sparse as sp
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.preprocessing import normalize as l2

from .normalize import normalize, mine_scaffolds, strip_scaffolds, split_scaffold


def register_of(q, sc):
    """The scaffold (= register instruction) wrapping q, canonicalised, or '' if none."""
    return split_scaffold(q, sc)[1]


class BM25:
    def __init__(self, k1=1.5, b=0.75):
        self.k1, self.b = k1, b

    def fit(self, docs):
        self.cv = CountVectorizer(token_pattern=r"(?u)\b\w+\b")
        tf = self.cv.fit_transform(docs).tocsr().astype(np.float32)
        n = tf.shape[0]
        dl = np.asarray(tf.sum(1)).ravel()
        df = np.bincount(tf.indices, minlength=tf.shape[1])
        self.idf = np.log(1 + (n - df + 0.5) / (df + 0.5)).astype(np.float32)
        tf = tf.tocoo()
        denom = tf.data + self.k1 * (1 - self.b + self.b * dl[tf.row] / dl.mean())
        w = tf.data * (self.k1 + 1) / denom * self.idf[tf.col]
        self.M = sp.csr_matrix((w, (tf.row, tf.col)), shape=tf.shape)
        return self

    def scores(self, queries):
        q = self.cv.transform(queries)
        q.data[:] = 1.0
        return (q @ self.M.T).toarray()


VIEWS_ALL = ("qq_char", "qq_word", "qq_bm25", "qa_char", "qa_word", "register")


class SankofaRetriever:
    """Retrieve a vetted answer *cluster* for a question.

    flags:
      norm     : script/keyboard-aware normalization
      scaffold : paraphrase-invariant scaffold stripping
      views    : subset of VIEWS_ALL to fuse with reciprocal-rank fusion
    """

    def __init__(self, lang, norm=True, scaffold=True, views=VIEWS_ALL, rrf_k=60, fusion="rrf",
                 weights=None):
        self.lang, self.norm, self.scaffold, self.views = lang, norm, scaffold, tuple(views)
        if not scaffold:
            self.views = tuple(v for v in self.views if v != "register")
        self.rrf_k, self.fusion, self.weights = rrf_k, fusion, weights

    def _prep(self, texts, is_q=True):
        out = []
        for t in texts:
            t = t if isinstance(t, str) else ""
            if is_q and self.scaffold:
                t = strip_scaffolds(t, self.sc)
            out.append(normalize(t, self.lang) if self.norm else t.lower())
        return out

    def fit(self, questions, answers):
        self.sc = mine_scaffolds(questions) if self.scaffold else {}
        self._train_questions = list(questions)
        akey = [" ".join(a.split()).strip() for a in answers]
        uniq = {}
        self.q2c = np.array([uniq.setdefault(a, len(uniq)) for a in akey])
        self.cluster_answer = [None] * len(uniq)
        for a_raw, k in zip(answers, akey):
            if self.cluster_answer[uniq[k]] is None:
                self.cluster_answer[uniq[k]] = a_raw
        self.nc = len(uniq)
        Q = self._prep(questions, True)
        A = self._prep(self.cluster_answer, False)
        self.m = {}
        if {"qq_char", "qa_char"} & set(self.views):
            self.cv = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), sublinear_tf=True, min_df=1)
            self.cv.fit(Q + A)
            self.m["qq_char"] = self.cv.transform(Q)
            self.m["qa_char"] = self.cv.transform(A)
        if {"qq_word", "qa_word"} & set(self.views):
            self.wv = TfidfVectorizer(analyzer="word", ngram_range=(1, 2), sublinear_tf=True,
                                      token_pattern=r"(?u)\b\w+\b")
            self.wv.fit(Q + A)
            self.m["qq_word"] = self.wv.transform(Q)
            self.m["qa_word"] = self.wv.transform(A)
        if "qq_bm25" in self.views:
            self.bm = BM25().fit(Q)
        if "register" in self.views:
            regs = [register_of(q, self.sc) for q in questions]
            self.reg_vocab = {r: i for i, r in enumerate(sorted(set(regs)))}
            self.qreg = np.array([self.reg_vocab[r] for r in regs])
        # one-hot question->cluster map for max-pooling
        return self

    def _pool(self, S):
        """max-pool question-level scores into cluster-level scores."""
        out = np.full((S.shape[0], self.nc), -1e9, dtype=np.float32)
        order = np.argsort(self.q2c, kind="stable")
        c_sorted = self.q2c[order]
        bounds = np.flatnonzero(np.r_[True, c_sorted[1:] != c_sorted[:-1], True])
        Ss = S[:, order]
        out = np.maximum.reduceat(Ss, bounds[:-1], axis=1)
        clusters = c_sorted[bounds[:-1]]
        res = np.empty((S.shape[0], self.nc), dtype=np.float32)
        res[:, clusters] = out
        return res

    def view_scores(self, queries):
        Q = self._prep(queries, True)
        sc = {}
        for v in self.views:
            if v == "qq_char":
                sc[v] = self._pool((self.cv.transform(Q) @ self.m[v].T).toarray())
            elif v == "qq_word":
                sc[v] = self._pool((self.wv.transform(Q) @ self.m[v].T).toarray())
            elif v == "qq_bm25":
                sc[v] = self._pool(self.bm.scores(Q))
            elif v == "qa_char":
                sc[v] = (self.cv.transform(Q) @ self.m[v].T).toarray()
            elif v == "qa_word":
                sc[v] = (self.wv.transform(Q) @ self.m[v].T).toarray()
            elif v == "register":
                qr = np.array([self.reg_vocab.get(register_of(q, self.sc), -1) for q in queries])
                S = (qr[:, None] == self.qreg[None, :]).astype(np.float32)
                sc[v] = self._pool(S)
        # per-query max normalisation so views are commensurable
        for v in sc:
            if v != "register":
                mx = sc[v].max(1, keepdims=True)
                sc[v] = sc[v] / np.where(mx > 0, mx, 1)
        return sc

    def fuse(self, sc):
        if self.fusion == "weighted":
            w = self.weights or {v: 1.0 for v in sc}
            return sum(w.get(v, 0.0) * S for v, S in sc.items())
        return self._rrf(sc)

    def score(self, queries, extra=None, sc=None):
        sc = dict(sc) if sc is not None else self.view_scores(queries)
        if extra:
            sc.update(extra)
        return self.fuse(sc), sc

    def _rrf(self, sc):
        if len(sc) == 1:
            return next(iter(sc.values()))
        fused = 0.0
        for S in sc.values():
            ranks = np.argsort(np.argsort(-S, axis=1), axis=1)
            fused = fused + 1.0 / (self.rrf_k + 1 + ranks)
        return fused

    def predict(self, queries, extra=None, sc=None):
        fused, sc = self.score(queries, extra, sc)
        top = fused.argmax(1)
        srt = np.sort(fused, 1)
        margin = srt[:, -1] - srt[:, -2] if fused.shape[1] > 1 else srt[:, -1]
        # confidence features (view agreement + similarity of the chosen cluster)
        r = np.arange(len(top))
        agree = np.mean([sc[v].argmax(1) == top for v in sc], 0)
        sims = {v: sc[v][r, top] for v in sc}
        return top, dict(margin=margin, agree=agree, top=srt[:, -1], **{f"sim_{v}": s for v, s in sims.items()})
