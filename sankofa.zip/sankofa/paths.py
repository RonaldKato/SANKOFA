"""Where data and results live. Override with SANKOFA_DATA / SANKOFA_RESULTS."""
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.environ.get("SANKOFA_DATA", os.path.join(ROOT, "data")) + os.sep
RESULTS = os.environ.get("SANKOFA_RESULTS", os.path.join(ROOT, "results")) + os.sep
os.makedirs(RESULTS, exist_ok=True)
