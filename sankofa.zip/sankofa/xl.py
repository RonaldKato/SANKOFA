"""Cross-lingual paraphrase view: let a local-language query match the *English twin* of a
local answer cluster (twins found by the anchor-bootstrapped Bridge), so that the many
English paraphrases in the national English bank become extra evidence for local answers."""
import numpy as np
from .bridge import Bridge, toks
from .metrics import akey


def cluster_docs(questions, answers):
    keys, order, qs = {}, [], []
    for q, a in zip(questions, answers):
        k = akey(a)
        if k not in keys:
            keys[k] = len(order); order.append(a); qs.append([])
        qs[keys[k]].append(q)
    return order, qs


class XLView:
    def __init__(self, loc_lang, min_pair_score=0.0):
        self.loc_lang, self.min_pair_score = loc_lang, min_pair_score

    def fit(self, R_local, E_questions, E_answers):
        L_ans = R_local.cluster_answer
        L_qs = [[] for _ in L_ans]
        for q, c in zip(R_local._train_questions, R_local.q2c):
            L_qs[c].append(q)
        E_ans, E_qs = cluster_docs(E_questions, E_answers)
        self.B = Bridge(self.loc_lang).fit([a + " " + " ".join(q) for a, q in zip(E_ans, E_qs)],
                                           [a + " " + " ".join(q) for a, q in zip(L_ans, L_qs)])
        self.e2l = {i: j for i, j, s in self.B.pairs if s >= self.min_pair_score}
        # English question matrix, pooled to English clusters that have a local twin
        eq, ec = [], []
        for i, qs in enumerate(E_qs):
            if i in self.e2l:
                for q in qs:
                    eq.append(toks(q, "Eng")); ec.append(self.e2l[i])
        self.XEq = self.B.wv.transform(eq)
        self.lc = np.array(ec)
        self.nL = len(L_ans)
        return self

    def scores(self, queries):
        Xq = self.B.translate_queries(queries)
        S = (Xq @ self.XEq.T).toarray()
        out = np.zeros((len(queries), self.nL), dtype=np.float32)
        if S.shape[1]:
            order = np.argsort(self.lc, kind="stable")
            cs = self.lc[order]
            b = np.flatnonzero(np.r_[True, cs[1:] != cs[:-1]])
            out[:, cs[b]] = np.maximum.reduceat(S[:, order], b, axis=1)
        mx = out.max(1, keepdims=True)
        return out / np.where(mx > 0, mx, 1)
